
package main

import (
	"fmt"
	"errors"
)

func doSomething( arg int ) (int, error) {
	if arg == 42 {
		return -1, errors.New("Can't Work With 42")
	}

	return arg + 10, nil
}

var ErrOutOfTea = fmt.Errorf("No More Tea Available")
var ErrPower 	= fmt.Errorf("Can't Boil Water")

func makeTea( arg int ) error {
	if arg == 2 {
		return ErrOutOfTea
	} else if arg == 4 {
		return fmt.Errorf("Making Tea: %w", ErrPower)
	}

	return nil
}

func playWithErrors() {
	for _, i := range []int{ 7, 42 } {
		if result, err := doSomething( i ) ; err != nil {
			fmt.Println("doSomething Failed:", err )
		} else {
			fmt.Println("doSomething Worked!:", result )
		}
	}

	for i := range 5 {
		if err := makeTea(i ) ; err != nil {
			if errors.Is( err, ErrOutOfTea ) {
				fmt.Println("We Should Buy Tea Powder!")
			} else if errors.Is( err, ErrPower ) {
				fmt.Println("Now It's Dark")
			} else {
				fmt.Printf("Unknown Error!: %s\n", err)
			}
			continue
		}

		fmt.Println("Tea Is Ready!")
	}
}

//__________________________________________________
// CUSTOM ERRORS


// Custom Error Defined
type argError struct {
	arg 	int
	message string
}

// METHOD ON RECEIVER TYPE argError

func ( err *argError ) Error() string {
	return fmt.Sprintf("%d-%d", err.arg, err.message)
}

func doMagic( arg int ) ( int, error ) {
	if arg == 42 {
		return -1, &argError{arg, "Can't Work With It!"}
	}

	return arg + 11, nil
}

func playWithCustomErrors() {
	_, err := doMagic( 42 )

	var argErr *argError
	if errors.As( err, &argErr ) {
		fmt.Println( argErr.arg )
		fmt.Println( argErr.message )
	} else {
		fmt.Println("Error Doesn't Match argError")
	}
}

//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithErrors");
	playWithErrors();

	fmt.Println("\nFunction: playWithCustomErrors");
	playWithCustomErrors()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

