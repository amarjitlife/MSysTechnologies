
package main

import "fmt"

//__________________________________________________

func sumInts( m map[string]int64 ) int64 {
	var total int64

	for _, v := range m {
		total += v
	}
	return total
}

func sumFloats( m map[string]float64 ) float64 {
	var total float64

	for _, v := range m {
		total += v
	}
	return total
}

// Generic Function
func sumIntsOrFloats[K comparable, V int64 | float64]( m map[K]V ) V {
	var total V

	for _, v := range m {
		total += v
	}
	return total
}

func playWithGenerics() {
	ints := map[string]int64 {
		"first" : 34,
		"second": 12,
	}

	floats := map[string]float64 {
		"first" : 35.98,
		"second": 90.90,
	}

	fmt.Printf("\nNonGeneric Sums: %v and %v", sumInts( ints), sumFloats( floats ))
	fmt.Printf("\nGeneric Sums: %v and %v", 
		sumIntsOrFloats( ints), 
		sumIntsOrFloats( floats ))
}


//__________________________________________________

type Number interface {
	int64 | float64
}

// Generic Function
func SumNumbers[K comparable, V Number]( m map[K]V ) V {
	var total V

	for _, v := range m {
		total += v
	}
	return total
}

func playWithGenericsAgain() {
	ints := map[string]int64 {
		"first" : 34,
		"second": 12,
	}

	floats := map[string]float64 {
		"first" : 35.98,
		"second": 90.90,
	}

	fmt.Printf("\nGeneric Sums: %v and %v", 
		SumNumbers( ints), 
		SumNumbers( floats ))
}

//__________________________________________________

type List[ T any ] struct {
	head, tail * element[T]
}

type element[T any] struct {
	next * element[T]
	val T
}

func MapKeys[K comparable, V any]( m map[K]V ) []K {
	r := make( []K, 0, len( m ) )
	for k := range m {
		r = append( r, k )
	}

	return r
}

func ( lst *List[T] ) Push( v T ) {
	if lst.tail == nil {
		lst.head = &element[T] { val : v }
		lst.tail = lst.head
	} else {
		lst.tail.next = &element[T] { val : v }
		lst.tail = lst.tail.next
	}
}

func (lst *List[T]) GetAll() []T {
	var elems []T

	for e := lst.head ; e != nil ; e = e.next {
		elems = append( elems, e.val )
	}
	return elems
}

func playWithGenericsOnceAgain() {
	var m = map[int]string{ 1 : "1", 2 : "4", 4 : "8" }

	fmt.Println("Keys : ", MapKeys(m) )

	result := MapKeys[int, string](m)
	fmt.Println("Keys : ", result )

	lst := List[int]{}
	lst.Push(10)
	lst.Push(11)
	lst.Push(22)
	lst.Push(99)
	lst.Push(77)	

	fmt.Println("List: ", lst.GetAll() )

}
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithGenerics");
	playWithGenerics()

	fmt.Println("\nFunction: playWithGenericsAgain");
	playWithGenericsAgain()

	fmt.Println("\nFunction: playWithGenericsOnceAgain");
	playWithGenericsOnceAgain()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

