
package main

import (
	"fmt"
	"time"
)

func spinner( delay time.Duration ) {
	for {
		for _, symbol := range `-\|/` {
			fmt.Printf("\r%c", symbol)
			time.Sleep( delay )
		}
	}
}

func fib( x int ) int {
	if x < 2 {
		return x
	}
	return fib( x - 1 ) + fib( x - 2 )
}

func playWithFibbonacci() {
	// spinner( 100 * time.Millisecond )

	// Heavy Work As Go Routine
	go spinner( 100 * time.Millisecond )

	const n = 3
	fibN := fib( n )
	fmt.Printf("\rFibonacci( %d ) = %d\n", n, fibN )
}

func main() {
	playWithFibbonacci()
}

