
package iniminimum

import (
	"fmt"
	"testing"
)

// func IntMin( a, b int ) int {
// 	if a < b { return a }
// 	return b
// }

func TestIntMinBasic(t *testing.T) {
	ans := IntMin( 20, -20 )
	if ans != -20 {
		t.Errorf("IntMin(20, -20) = %d ; want -20", ans )
	}
}

func TestIntMinTableDriven(t *testing.T) {
	var tests = []struct {
		a, b int
		want int
	}{
		{0, 1, 0},
		{1, 0, 0},
		{2, -2, -2},
		{0, -1, -1},
		{-1, 0, -1},			
	}

	for _, tt := range tests {
		testname := fmt.Sprintf("%d, %d", tt.a, tt.b)
		t.Run( testname, func( t* testing.T) {
			ans := IntMin( tt.a, tt.b )
			if ans != tt.want {
				t.Errorf("Got %d, Want %d", ans, tt.want)
			}
		})
	}
}
