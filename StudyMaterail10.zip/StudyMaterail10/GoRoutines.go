
package main

import (
	"fmt"
	"time"
)

func doSomething( from string ) {
	for i := 0 ; i < 3 ; i++ {
		fmt.Println( from, " : ", i )
		time.Sleep( time.Second * 2 )
	}
}

func playWithGoRoutines() {
	fmt.Println( time.Now().Format( time.RFC850 ) )

	// doSomething( " Direct" ) // Blocking Function Call
	go doSomething( " Direct" ) // Non[Blocking Functions Call

	// doSomething( " Once More Called...") // Blocking Function Call
	go doSomething( " Once More Called...") // Non[Blocking Functions Call

	// func( message string ) { // Blocking Function Call
	// 	fmt.Println( message )
	// 	time.Sleep( time.Second * 3 )
	// }("Here Goes Closure Called...")

	go func( message string ) { // Non[Blocking Functions Call
		fmt.Println( message )
		time.Sleep( time.Second * 3 )
	}("Here Goes Closure Called...")

	time.Sleep( time.Second * 6 )
	fmt.Println( "DONE!!")

	fmt.Println( time.Now().Format( time.RFC850 ) )
}


func main() {
	fmt.Println("\nFunction: playWithGoRoutines");
	playWithGoRoutines()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

// Function: playWithGoRoutines
// Monday, 01-Jul-24 18:56:27 IST
//  Direct  :  0
//  Direct  :  1
//  Direct  :  2
//  Once More Called...  :  0
//  Once More Called...  :  1
//  Once More Called...  :  2
// Here Goes Closure Called...
// DONE!!
// Monday, 01-Jul-24 18:56:45 IST


