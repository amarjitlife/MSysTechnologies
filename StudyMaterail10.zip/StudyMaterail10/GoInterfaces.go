
package main

import (
	"fmt"
	"math"
	"log"
	"strconv"
	"os"
	"encoding/json"
	"io"
	"bytes"
)

//__________________________________________________
// In Java
/*
inteface Geometry {
	public float area()
	public float perimeter() 
}

//	Explicitly Speficy Interface To Be Implemented
class Rectangle implements Geometry {
	public float area() {
		// Write Logic Here...
	}

	public float perimeter() {

	}
}
*/

//__________________________________________________
// IN GO
//		Interfaces Conformance Happens Implicitly

// DUCK TYPING
//		Anything Which Quack Like Duck!
//		Which Swim Like Duck!
// IS A DUCK!!!

type Rectangle struct {
	width, height float64
}

type Circle struct {
	radius float64
}

// Methods On Receiver Type Rectangle
func ( r Rectangle ) area() float64 {
	return r.width * r.height
}

func ( r Rectangle ) perimeter() float64 {
	return 2 * ( r.width + r.height )
}

// Methods On Receiver Type Circle
func ( c Circle ) area() float64 {
	return math.Pi * c.radius * c.radius
}

func ( c Circle ) perimeter() float64 {
	return 2 * math.Pi * c.radius
}

func ( c Circle ) origin() (float64, float64) {
	return 0.0, 0.0
}

type Geometry interface {
	area() float64
	perimeter() float64
}

// Polymorphic Function
//		Using Mechanism: Interface As Arguments
func measureGeometry( g Geometry ) {
	fmt.Println()
	fmt.Println( "Geometry          : ", g )
	fmt.Println( "Geometry Area     : ", g.area() )
	fmt.Println( "Geometry Perimeter: ", g.perimeter() )	
}

func playWithGeometry() {
	r := Rectangle{ width: 10, height: 2 }
	c := Circle{ radius: 10 }

	// fmt.Printf("\nRectangle Area: %f  Perimeter: %f", r.area(), r.perimeter() )
	fmt.Printf("\nCircle Area: %f  Perimeter: %f", c.area(), c.perimeter() )

	// cannot use r (variable of type Rectangle) as Geometry value 
	// in argument to measureGeometry: Rectangle does not implement 
	// Geometry (missing method perimeter)
	measureGeometry( r )
	measureGeometry( c )
}

//__________________________________________________

type Stringer interface {
	String() string
}

type Book struct {
	Title string
	Author string
}

func ( b Book ) String() string {
	return fmt.Sprintf("Book: %s - %s", b.Title, b.Author )
}

type Number int

func ( n Number ) String() string {
	return strconv.Itoa( int( n ) )
}

func WrtieLog( s fmt.Stringer ) {
	log.Println( s.String() )
}

func playWithStringerInterface() {
	book := Book{ "War and Peace", "Leo Tolstoy" }
	WrtieLog( book )

	count := Number(10)
	WrtieLog( count )
}

//__________________________________________________

type Writer interface {
	Write( p []byte ) ( n int, err error )
}

type Customer struct {
	Name string
	Age int
}

func ( c *Customer ) WriteJSON( w io.Writer ) error {
	jsonData, err := json.Marshal( c )
	if err != nil { return err }

	_, err = w.Write( jsonData )
	return err
}

func playWithWriterInterace() {
	c := &Customer{ Name: "Gabbar Singh", Age: 30 }

	var buf bytes.Buffer 
	err := c.WriteJSON( &buf )
	if err != nil { log.Fatal( err ) }

	file, err := os.Create("/tmp/customerFile.json")
	if err != nil { log.Fatal( err ) }
	defer file.Close()

	err = c.WriteJSON( file )
	if err != nil { log.Fatal( err ) }
}

//__________________________________________________

// package fmt

// func Fprintf(w io.Writer, format string, args ...interface{}) (int, error)

// func Printf(format string, args ...interface{}) (int, error) {
// 	 return Fprintf(os.Stdout, format, args...)
// }

// func Sprintf(format string, args ...interface{}) string {
// 	var buf bytes.Buffer
// 	Fprintf(&buf, format, args...)
// 	return buf.String()
// }  


// package io

// type Writer interface {
// 	// Write writes len(p) bytes from p to the underlying data stream.
// 	// It returns the number of bytes written from p (0 <= n <= len(p))
// 	// and any error encountered that caused the write to stop early.
// 	// Write must return a non-nil error if it returns n < len(p).
// 	// Write must not modify the slice data, even temporarily.
// 	//
// 	// Implementations must not retain p.
// 	Write(p []byte) (n int, err error)
// }

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithGeometry");
	playWithGeometry()

	fmt.Println("\nFunction: playWithStringerInterface");
	playWithStringerInterface()

	fmt.Println("\nFunction: playWithWriterInterace");
	playWithWriterInterace()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

