
package main

import (
	"io"
	"log"
	"net"
	"time"
	"fmt"
)

func handleConnectin( connection net.Conn ) {
	defer connection.Close()

	for {
		_, err := io.WriteString( connection, time.Now().Format("15:04:05\n"))
		if err != nil {
			return
		}

		time.Sleep( 1 * time.Second )
	}
}

func tcpServer() {
	listener, err := net.Listen("tcp", "localhost:8000")
	if err != nil {
		log.Fatal( err )
	}

	for {
		connection, err := listener.Accept()
		if err != nil {
			log.Print( err )
			continue
		}
		go handleConnectin( connection )
 	}
}


func main() {
	fmt.Println("\nFunction : tcpServer ")
	tcpServer()
}