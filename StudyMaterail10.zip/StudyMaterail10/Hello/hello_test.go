

package hello

import "testing"

func TestHello( t * testing.T ) {
	//want := "Hello World!!!"
	want := "Hello, world."
	if got := Hello() ; got != want {
		t.Errorf("Hello() = %q, Want %q", got, want)
	}
}

