
package main

import (
	"fmt"
	"bufio"
	"os"
	"strings"
	"strconv"
	"unicode/utf8"
	"unicode"
	"io"
	"encoding/json"
	"log"
)

//__________________________________________________

func playWithArrays() {
	// Creating Array of 3 Ints
	//		Array Index Starts Frm 0 Till (len - 1)
	//		All The Elements Of Array Are Initialised 
	//			To Default Values Of Type
	//			int Type Default Vlaue 0
	var a [3]int

	fmt.Printf("\nData Type: %T", a )

	for index, value := range a {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[ len( a ) - 1 ] )

	// Compiler Time Error
	// ./GoCompositeTypes.go:25:18: invalid argument: index 3 out of bounds [0:3]
	// fmt.Println( a[ len( a ) ] )

	for _, value := range a {
		fmt.Println( value )
	}

	var q [5]int = [5]int { 10, 20, 30, 40, 50 }
	var r [5]int = [5]int { 10, 20, 30 }

	fmt.Printf("\nData Type: %T", q )
	fmt.Printf("\nData Type: %T", r )


	fmt.Println("\nArray Length: ", len( q ) )
	for index, value := range q {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	fmt.Println("\nArray Length: ", len( r ) )
	for index, value := range r {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	// 1. Type Inferencing Will Happen From RHS : [4]int
	// 2. Inferred Type Binded With LHS
	s := [...]int{ 10, 20, 100, 111 }
	fmt.Println("\nArray Length: ", len( s ) )
	for index, value := range s {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}
	fmt.Printf("\nData Type: %T", s )

	// Creating Slice
	ss := []int{ 10, 20, 100, 111 }
	fmt.Println("\nArray Length: ", len( ss ) )
	for index, value := range ss {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}
	fmt.Printf("\nData Type: %T", ss )

	some := [3]int { 100, 200, 300 }
	fmt.Println("\nArray Length: ", len( some ) )	
	fmt.Printf("\nData Type: %T", some )

	someAgain := [...]int { 99 : - 1 }
	fmt.Println("\nArray Length: ", len( someAgain ) )
	fmt.Printf("\nData Type: %T", someAgain )

	for index, value := range someAgain {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

// Array Length:  3
// Data Type: [3]int

// Array Length:  100
// Data Type: [100]int

	something := [10]int { 10, 20, 5 : 99, 7 : 88 }
	fmt.Println("\nArray Length: ", len( something ) )
	fmt.Printf("\nData Type: %T", something )

	for index, value := range something {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	aa := [2]int { 10, 20 }
	bb := [...]int {10, 20 }
	cc := [2]int{ 10, 30 }

	// In Go Lang
	//		Can Compare Arrays Using == Operator
	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	dd := [3]int { 10, 30 }
	fmt.Println( dd )

	// Compilation Error
	// invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )
}

//__________________________________________________

func playWithSlices() {
	// Array Of Strings
	months := [...]string { 0: "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", 
					"Aug", "Sep", "Oct", "Nov", "Dec" }
	fmt.Println( months )

	// Slices
	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer 	:= months[ 2 : 7 ]

	fmt.Println( "Quater1 :", quater1 )
	fmt.Println( "Quater2 :", quater2 )
	fmt.Println( "Summear :", summer )

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf(" %s Month Appears In Both\n", s)
			}
		}
	}

	fmt.Printf("\n Data Type: %T", months )
	fmt.Printf("\n Data Type: %T", quater1 )
	fmt.Printf("\n Data Type: %T", quater2 )
	fmt.Printf("\n Data Type: %T", summer)

// Array Type
	 // Data Type: [13]string

// Slices Type
	 // Data Type: []string
	 // Data Type: []string
	 // Data Type: []string

	fmt.Println()
	fmt.Println( quater1[0] )
	fmt.Println( quater1[1] )
	fmt.Println( quater1[2] )

	fmt.Println( months[0] )
	fmt.Println( months[1] )
	fmt.Println( months[2] )

	fmt.Println()
	fmt.Println( quater2[0] )
	fmt.Println( quater2[1] )
	fmt.Println( quater2[2] )
}

//_____________________________________________________________________________________
// 						
// 									GO SLICES CONCEPTS
//_____________________________________________________________________________________

// Slices represent variable-length sequences whose elements all have 
//	the same type. A slice type is written []T, where the elements 
//  have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence 
// (or perhaps all) of the elements of an array, which is known as the 
// slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is reachable 
//			through the slice, which is not necessarily the array’s first element. 
// 		The length is the number of slice elements; it can’t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 	which may be an array variable, a pointer to an array, or another slice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j is omitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of valid months, 
// 	as does the slice months[1:]; the slice months[:] refers to the whole array.


//__________________________________________________

// In Go Lang
//		By Default Arrays Are Pass By Value

// In Java/C/C++
//		By Default Arrays Are Pass By Reference

func changeArray( someArray [5]int ) {
	fmt.Println("Inside changeArray Function: ", someArray )
	for index, _ := range someArray {
		someArray[index] = 777
	}

	fmt.Println("Inside changeArray Function: ", someArray )
}

// Here Array Is Passed By Reference
func changeArray1( someArray * [5]int ) {
	fmt.Println("Inside changeArray Function: ", someArray )
	for index, _ := range someArray {
		someArray[index] = 777
	}

	fmt.Println("Inside changeArray Function: ", someArray )
}

// In Go Lang
//		Slices Are Pass By Reference
func changeArray2( someSlice []int ) {
	fmt.Println("Inside changeArray Function: ", someSlice )
	for index, _ := range someSlice {
		someSlice[index] = 777
	}

	fmt.Println("Inside changeArray Function: ", someSlice )
}

func playWithChangeArray() {
	var aa [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println( "Array Before changeArray Called:", aa )
	changeArray( aa )
	fmt.Println( "Array After  changeArray Called:", aa )

	fmt.Println( "Array Before changeArray1 Called:", aa )
	changeArray1( &aa ) // Passing Array Reference
	fmt.Println( "Array After  changeArray1 Called:", aa )

	var bb [5]int = [5]int { 10, 20, 30, 40, 50 }
	fmt.Println( "Array Before changeArray2 Called:", bb )
	// Passing Array Slice of Full Array 
	//		Slice Index From 0 To len -1 i.e. bb[ 0 : len - 1 ]
	changeArray2( bb[ : ] ) 
	fmt.Println( "Array After  changeArray2 Called:", bb )

	var cc [10]int = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }
	fmt.Println( "Before changeArray2:", cc )
	changeArray2( cc [ : 4 ] )
	changeArray2( cc [ 6 : ] )
	changeArray2( cc [ 3 : 7  ] )
	fmt.Println( "After changeArray2:", cc )

}

//__________________________________________________

func reverse( slice []int ) {
	for i, j := 0, len( slice ) -1  ;  i < j  ;  i, j = i + 1, j - 1 {
		slice[i], slice[j] = slice[j], slice[i]
	}
}

// func slicesEqual( x []int, y []int ) bool {
func slicesEqual( x, y []int ) bool {
	if len( x ) != len( y ) {
		return false 
	}

	for i := range x {
		if x[i] != y[i] {
			return false
		}
	}
	return true
}

func playWithArrayAndSlices() {
	// a Is An Array
	a := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 90 }
	
	fmt.Println( a )
	reverse( a [ : ] )
	fmt.Println( a )

	// s Is A Slice: Array Syntax Withoud Size Information
	s := []int { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	
	fmt.Printf("Type : %T\n", s )
	fmt.Println( s )

	reverse ( s[ : 5 ] )

	fmt.Println( s )
	reverse ( s[ 5 :  ] ) 
	fmt.Println( s )

	changeArray2( s[ 3 : 6 ] )
	fmt.Println( s )

	slice1 := a[ 2 : 6 ]
	slice2 := a[ 2 : 6 ]
	slice3 := a[ 5 : 8 ]

	// invalid operation: slice1 == slice2 (slice can only be compared to nil)
	// fmt.Println( slice1 == slice2 )
	// fmt.Println( slice1 == slice3 )
	// fmt.Println( slice2 == slice3 )

	fmt.Println( slicesEqual( slice1, slice2 )  )
	fmt.Println( slicesEqual( slice1, slice2 )  )
	fmt.Println( slicesEqual( slice2, slice3 )  )
}

// Function: playWithArrayAndSlices
// [10 20 30 40 50 60 70 80 90]
// [90 80 70 60 50 40 30 20 10]
// Type : []int
// [1 2 3 4 5 6 7 8 9 10]
// [5 4 3 2 1 6 7 8 9 10]
// [5 4 3 2 1 10 9 8 7 6]
// Inside changeArray Function:  [2 1 10]
// Inside changeArray Function:  [777 777 777]
// [5 4 3 777 777 777 9 8 7 6]

//__________________________________________________

func playWithSlicesFunctions() {

	s := make( []string, 3 )
	fmt.Println("\nEmpty Slice: \n", s)
	fmt.Printf("\nEmpty Slice Type: %T", s )
	fmt.Printf("\nLength : %d  Capacity: %d", len( s ), cap( s ) )

	s[0] = "a"
	s[1] = "b"
	s[2] = "c"

	fmt.Println("\nSlice :", s )
	fmt.Printf("\nLength : %d  Capacity: %d", len( s ), cap( s ) )

	s = append( s, "d" )	
	fmt.Println("\nSlice : ", s )
	fmt.Printf("\nLength : %d  Capacity: %d", len( s ), cap( s ) )

	s = append( s, "e", "f" )
	fmt.Println("\nSlice : ", s )
	fmt.Printf("\nLength : %d  Capacity: %d", len( s ), cap( s ) )

	s = append( s, "mm" )	
	fmt.Println("\nSlice : ", s )
	fmt.Printf("\nLength : %d  Capacity: %d", len( s ), cap( s ) )	


 	c := make( []string, len( s) )
	fmt.Println("\ns Slice : ", s )
	fmt.Printf("\ns Slice Type: %T", s )

	fmt.Println("\nc Slice : ", c )
	fmt.Printf("\nc Slice Type: %T", c )

	fmt.Println("\ns Slice : ", s )
	fmt.Println("\nc Slice : ", c )

	// Shallow Copy
	// Reference Assingment i.e. Both c and s Are Pointin
	//		To Same Underground Array
	c = s 

	fmt.Println("\ns Slice : ", s )
	fmt.Println("\nc Slice : ", c )

	s[0] = "A"

	fmt.Println("\ns Slice : ", s )
	fmt.Println("\nc Slice : ", c )

	// s Slice :  [A b c d e f mm]
	// c Slice :  [A b c d e f mm]	

	ss := make( []string, 0 )
	fmt.Println("\nss Slice : ", ss )

	ss = append( ss, "AA", "BB", "CC" )
	fmt.Println("\nss Slice : ", ss )

	cc := make ( []string, len( ss ) )

	copy( cc, ss ) // Deep Copy
	fmt.Println("\nss Slice : ", ss )
	fmt.Println("\ncc Slice : ", cc )

	ss[0] = "XX"
	fmt.Println("\nss Slice : ", ss )
	fmt.Println("\ncc Slice : ", cc )
}


//__________________________________________________


func playWithReadingInputs() {
	
	input := bufio.NewScanner( os.Stdin )

	outer:
		for input.Scan() {
			var ints []int
		
			for _, s := range strings.Fields( input.Text() ) {
				x, error := strconv.ParseInt( s, 10, 64 )

				if error != nil {
					fmt.Println( os.Stderr, error )
					continue outer
				}

				ints = append( ints, int( x ) )
			}

			fmt.Printf(" %v \n", ints )
			reverse( ints )
			fmt.Printf(" %v \n", ints )
		}
}


//__________________________________________________

// 2 Dimentional : Jagged Array
func playWith2DimentinalData() {

	twoD := make( [][]int, 3 )

	for i := 0 ; i < 3 ; i++  {
		
		innerLen := i + 1
		twoD[i] = make( []int, innerLen )

		for j := 0 ; j < innerLen ; j++  {
			twoD[i][j] = i + j
		}
	}

	fmt.Println("2 Dimentional Array: ", twoD )
}

//__________________________________________________

func appendInt( x []int, y int ) []int {
	var z []int

	zlen := len( x ) + 1
	if zlen <= cap( x ) {
		z = x[ : zlen ]
	} else {
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * len( x )
		}

		z = make( []int, zlen, zcap )
		copy( z, x )
	}

	z[ len( x ) ] = y
	return z
}

func playWithAppendInt() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = append( x, i )
		fmt.Printf("\n%d Capacity: %d \t %v ", i, cap( y ), y )
		x = y
	}
}

//__________________________________________________

func summation( numbers ...int ) int {
	fmt.Print( numbers )
	total := 0

	for _, number := range numbers {
		total = total + number 
	}

	return total
}

func playWithSummation() {
	var result int

	result = summation()
	fmt.Println("\nresult : ", result)

	result = summation(111)
	fmt.Println("\nresult : ", result)

	result = summation(10, 20, 30, 40, 50)
	fmt.Println("\nresult : ", result)

	numbers := []int{ 1, 2, 3, 4, 5, 6, 7, 8 }
	result = summation( numbers... )
	fmt.Println("\nresult : ", result)
}


//__________________________________________________


func appendSlice( x []int, y ...int ) []int {
	var z []int

	zlen := len(x) + len( y )
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Array Is Full, Allocate A New Array
		//	To Append Additional Data
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x) 	// Pool Size Increased
		}
		
		z = make( []int, zlen, zcap )
		copy(z, x)
	}
	copy( z[ len(x) : ], y )
	return z
}

func playWithAppendSlices() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendSlice(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
	fmt.Println( x )

	x = appendSlice(x , 10, 20, 30 )
	fmt.Println( x )

	x = appendSlice(x , 11, 22, 33, 44, 55, 66 )
	fmt.Println( x )

	numebrs := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	x = appendSlice( x, numebrs... )
	fmt.Println( x )	
}

//__________________________________________________

func playWithMaps() {
	m := make( map[string]int )

	m["k1"] = 70
	m["k2"] = 33

	fmt.Println("Map: ", m) 

	value1 := m["k1"]
	fmt.Println("Map Key Value: ", value1 )

	value2, status := m["k3"]
	fmt.Println("Map Key Value: ", value2, status )

	if status {// Good Pattern To Write
		fmt.Println("Map Key Value: ", value2 )	
	} else {
		fmt.Println("Key Doesn't Exists")
	}

	mm := map[string]int{ "Ding": 10, "Dong": 20, "Ting": 99, "Tong": 777}
	fmt.Println("Map: ", mm) 

	mmm := map[int]string { 10: "Ding", 20 : "Dong", 99 : "Ting", 7 : "Tong"}
	fmt.Println("Map: ", mmm) 
}

//__________________________________________________

// HOME WORK
// Test Input
// Hello Hello Hello Hello Hello 早上好

func countUnicodeCharaters() {
	counts := make( map[rune]int )

	var utflen [ utf8.UTFMax + 1 ]int
	invalid := 0

	in := bufio.NewReader( os.Stdin )

	for {
		r, n, err := in.ReadRune()
		if err == io.EOF {
			break
		}

		if err != nil {
			fmt.Fprintf( os.Stderr, "Charcount: %v\n", err )
			os.Exit( 1 ) 
		}

		if r == unicode.ReplacementChar && n == 1 {
			invalid++
			continue
		}

		counts[r]++
		utflen[n]++
	}

	fmt.Printf("rune\tcount\n")
	for c, n := range counts {
		fmt.Printf("%q\t%d\n", c, n)
	}
	fmt.Print("\nlen\tcount\n")
	for i, n := range utflen {
		if i > 0 {
			fmt.Printf("%d\t%d\n", i, n)
		}
	}
	if invalid > 0 {
		fmt.Printf("\n%d invalid UTF-8 Chaacters\n", invalid)
	}
}

//__________________________________________________
//
//						GO STRUCT 
//__________________________________________________

// DESIGN PRINCIPLE
//		DRY : Don't Repeat Yourself

type Circle struct {
	X, Y, Radius int
}

type Wheel struct {
	X, Y, Radius, Spokes int
}

func playWithCircleAndWheel() {
	var c Circle
	c.X = 10
	c.Y = 20
	c.Radius = 50

	fmt.Println("Circle : ", c)

	var w Wheel
	w.X = 11
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel : ", w )
}

//__________________________________________________

// Associative Types
//		Types Which Associated Various Types To Common Type

type Point1 struct {
	X, Y int
}

type Circle1 struct {
	Center Point1 
	Radius int
}

type Wheel1 struct {
	Circle Circle1
	Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1
	c.Center.X = 10
	c.Center.Y = 20
	c.Radius = 50

	fmt.Println("Circle1 : ", c)

	var w Wheel1
	w.Circle.Center.X = 11
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel1 : ", w )
}

//__________________________________________________

type Point struct {
	X, Y int
}

func ScalePoint( point Point, factor int ) Point {
	var newX = point.X * factor
	var newY = point.Y * factor 
	return Point{ newX, newY }
}

func AddPoint( point1 Point, point2 Point ) Point {
	var newX = point1.X + point2.X
	var newY = point1.Y + point2.Y
	return Point{ newX, newY }

}

func playWithPointType() {
	point1 := Point{ 10, 20 }
	point2 := Point{ 100, 200 }
	point3 := Point{ 11, 22 }

	fmt.Println("point1 : ", point1 )
	fmt.Println("point2 : ", point2 )
	fmt.Println("point3 : ", point3  )

	fmt.Println("Scaled point1 : ", ScalePoint(point1, 2) )
	fmt.Println("Scaled point2 : ", ScalePoint(point2, 5) )
	fmt.Println("Scaled point3 : ", ScalePoint(point3, 10)  )

	fmt.Println("Points Added: ", AddPoint( point1, point2 ))
	fmt.Println("Points Added: ", AddPoint( point1, point3 ))

	point4 := AddPoint( point1, point2 )
	fmt.Println( point4 )
}


//__________________________________________________
// {
// "Title": "Shole",
// "Year": 1980,
// "Color": true,
// "Actors": [
//   "Dharamendra",
//   "Amitabh",
//   "Hemamalani",
//   "GabbarSingh",
//   "Sanjeev Kumar"
// ]
// },

//  {
//     "Title": "Shole",
//     "Release Year": 1980,
//     "Movie Color": true,
//     "Actors": [
//       "Dharamendra",
//       "Amitabh",
//       "Hemamalani",
//       "GabbarSingh",
//       "Sanjeev Kumar"
//     ]
//   },

type Movie struct {
	Title string  	
	Year int  			`json:"Release Year"`
	Color bool   		`json:"Movie Color"`
	Actors []string
}

var movies = []Movie {
	{ Title: "Shole",Year: 1980, Color: true, Actors: []string{ "Dharamendra", "Amitabh", "Hemamalani", "GabbarSingh", "Sanjeev Kumar"} },
	{ Title: "Bajarangi Bhaijan", Year: 2010, Color: true, Actors: []string{ "Salman Khan", "Nawajudin Sidqui", "Little Girl"}},
	{ Title: "Mugle Azam", Year: 1970, Color: false , Actors: []string{ "Dilip", "Madhubala", "Prithvi Raj Kapoor"}},
	// { Title: "", Year: , Color: , Actors: []string{ "", "", ""}}
	// { Title: "", Year: , Color: , Actors: []string{ "", "", ""}}
}

func playWithMoviesMarshallingAndUnMarshalling() {
	for index, movie := range movies {
		fmt.Println( index, movie )
	}

	{
		// Converted Array Of Struct Data To JSON Data
		// jsonData and error Are Local To This Block {   }
		jsonData, error := json.Marshal( movies )
		if error != nil {
			log.Fatalf("JSON Marshalling Failed! %s", error )
		}

		fmt.Printf("%s", jsonData)
	}

	jsonData, error := json.MarshalIndent( movies, "", "    " )
	if error != nil {
		log.Fatalf("JSON Marshalling Failed! %s", error )
	}	

	fmt.Printf("%s", jsonData)

	var moviesData []Movie

	// error := json.Unmarshal( jsonData,  &moviesData ) 
	// if error != nil {
	// 		log.Fatalf("JSON UNMarshalling Failed! %s", error )
	// }

	//Idiom 
	if error := json.Unmarshal( jsonData,  &moviesData ) ; error != nil {
			log.Fatalf("JSON UNMarshalling Failed! %s", error )
	}
	fmt.Println("\nUnmarshalled Movies Data...")
	fmt.Println( moviesData )
	// [
	//  {Shole 1980 true [Dharamendra Amitabh Hemamalani GabbarSingh Sanjeev Kumar]} 
	//  {Bajarangi Bhaijan 2010 true [Salman Khan Nawajudin Sidqui Little Girl]
	//  { Mugle Azam 1970 false [Dilip Madhubala Prithvi Raj Kapoor]}
	//  ]

	var moviesTitle []struct { Title  string }
	if error := json.Unmarshal( jsonData,  &moviesTitle ) ; error != nil {
			log.Fatalf("JSON UNMarshalling Failed! %s", error )
	}
	fmt.Println("\nUnmarshalled Movies Data...")
	fmt.Println( moviesTitle )
}

//__________________________________________________

type PointType struct {
	X, Y int
}

type CircleType struct {
	// Center PointType
	PointType  // Type/Structure Embedding
	Radius int
}

type WheelType struct {
	// Circle CircleType
	CircleType
	Spokes int
}

func playWithCircleAndWheelTypes() {
	var w WheelType
	w.CircleType.PointType.X = 11
	w.CircleType.PointType.Y = 22
	w.CircleType.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel : ", w )

	// Can Access Members of Embedded Type/Structure Directly
	var ww WheelType
	ww.X = 11
	ww.Y = 22
	ww.Radius = 55
	ww.Spokes = 24

	fmt.Println("Wheel : ", ww )

}

// Function: playWithCircleAndWheelTypes
// Wheel :  {{{11 22} 55} 24}


//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithArrays");
	playWithArrays()

	fmt.Println("\nFunction: playWithSlices");
	playWithSlices()

	fmt.Println("\nFunction: playWithChangeArray");
	playWithChangeArray()

	fmt.Println("\nFunction: playWithArrayAndSlices");
	playWithArrayAndSlices()

	fmt.Println("\nFunction: playWithSlicesFunctions");
	playWithSlicesFunctions()

	// fmt.Println("\nFunction: playWithReadingInputs");
	// playWithReadingInputs()

	fmt.Println("\nFunction: playWith2DimentinalData");
	playWith2DimentinalData()

	fmt.Println("\nFunction: playWithAppendInt");
	playWithAppendInt()

	fmt.Println("\nFunction: playWithSummation");
	playWithSummation()

	fmt.Println("\nFunction: playWithAppendSlices");
	playWithAppendSlices()

	fmt.Println("\nFunction: playWithMaps");
	playWithMaps()

	// fmt.Println("\nFunction: countUnicodeCharaters");
	// countUnicodeCharaters()

	fmt.Println("\nFunction: playWithCircleAndWheel");
	playWithCircleAndWheel()

	fmt.Println("\nFunction: playWithCircleAndWheel1");
	playWithCircleAndWheel1()
	
	fmt.Println("\nFunction: playWithPointType");
	playWithPointType()

	fmt.Println("\nFunction: playWithMoviesMarshallingAndUnMarshalling");
	playWithMoviesMarshallingAndUnMarshalling()

	fmt.Println("\nFunction: playWithCircleAndWheelTypes");
	playWithCircleAndWheelTypes()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

