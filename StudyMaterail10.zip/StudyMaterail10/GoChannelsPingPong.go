

package main

import "fmt"

// pings Is Write Only Channel
func ping( pings chan<- string, msg string) {
	pings <- msg
}

// pings Is Read Only Channel
// pongs Is Write Only Channel
func pong( pings <-chan string, pongs chan<- string) {
	msg := <- pings
	pongs <- msg	
}

func main() {
	pings := make( chan string, 1 )
	pongs := make( chan string, 1 )

	ping( pings, "Hi Hellooo")
	pong( pings, pongs )

	fmt.Println( <-pongs )
}

