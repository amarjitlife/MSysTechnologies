
package main

import (
	"fmt"
	"time"
)

func main() { // Main Goroutine
	// Creating Unbuffered Channel
	// messages := make( chan string )

	// Creating Buffered Channel
	//		Having Buffer Size
	messages := make( chan string, 3 )

	go func() { // Go Routines
		// Writing To messages Channel
		messages <- "Ping"
		messages <- "Pong"
		messages <- "Ting"
		messages <- "Tong"

		close( messages )

		fmt.Println("Go Routine 2 Completed!!!")
	}()

	// Reading From messages Channel
	// msg := <- messages
	// fmt.Println( msg )

	// msg = <- messages
	// fmt.Println( msg )

	// msg = <- messages
	// fmt.Println( msg )

	// msg = <- messages
	// fmt.Println( msg )

	for msg := range messages {
		fmt.Println( msg )
	}

	time.Sleep( time.Second * 10 )
	fmt.Println("Main Go Routine Completed!!!")
}

