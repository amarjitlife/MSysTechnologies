
package main

import (
	"fmt"
	"math"
	"image/color"
)


//__________________________________________________

type Point struct {
	X, Y float64
}

// Functions Taking Point Type Arguments
func ScalePoint( point Point, factor int ) Point {
	var newX = point.X * float64( factor )
	var newY = point.Y * float64( factor ) 
	return Point{ newX, newY }
}

func AddPoint( point1 Point, point2 Point ) Point {
	var newX = point1.X + point2.X
	var newY = point1.Y + point2.Y
	return Point{ newX, newY }

}

func playWithPointType() {
	point1 := Point{ 10, 20 }
	point2 := Point{ 100, 200 }
	point3 := Point{ 11, 22 }

	fmt.Println("point1 : ", point1 )
	fmt.Println("point2 : ", point2 )
	fmt.Println("point3 : ", point3  )

	fmt.Println("Scaled point1 : ", ScalePoint(point1, 2) )
	fmt.Println("Scaled point2 : ", ScalePoint(point2, 5) )
	fmt.Println("Scaled point3 : ", ScalePoint(point3, 10)  )

	fmt.Println("Points Added: ", AddPoint( point1, point2 ))
	fmt.Println("Points Added: ", AddPoint( point1, point3 ))

	point4 := AddPoint( point1, point2 )
	fmt.Println( point4 )
}

//__________________________________________________

type PointType struct {
	X, Y float64
}

// Distance Function 
//		Taking Two Arguments Of PointType
func Distance( p PointType, q PointType ) float64 {
	return math.Hypot( q.X - p.X, q.Y - p.Y )
}

// Distance Method On Receiver PoinType
//		It's Taking One Argument Of PointType
func (p PointType) Distance( q PointType ) float64 {
	return math.Hypot( q.X - p.X, q.Y - p.Y )	
}

type PathType []PointType

// Distance Method On Receiver PathType
//		It's Taking NO Argument
func (path PathType) Distance() float64 {
	pathDistance := 0.0

	for index := range path {
		if index > 0 {
			pathDistance += path[ index - 1 ].Distance( path[ index ] ) 
		}
	}

	return pathDistance
}

func playWithFunctionsAndMethods() {
	point1 := PointType{ 10.0, 20.0 }
	point2 := PointType{ 100.0, 200.0 }

	fmt.Println("point1 : ", point1 )
	fmt.Println("point2 : ", point2 )

	distance := Distance( point1, point2 ) // Function Invocation
	fmt.Println("Distance Between Points: ", distance)

	distanceAgain := point1.Distance( point2 ) //Method Invocation
	fmt.Println("Distance Between Points: ", distanceAgain)

	var path PathType
	path = PathType{
		PointType{ 10.0, 20.0 },
		PointType{ 20.0, 30.0 },
		PointType{ 40.0, 60.0 },	
	}

 	pathDistance := path.Distance()
	fmt.Println("Path Distance Between Points: ", pathDistance)

}

//__________________________________________________

type ColoredPointType struct {
	PointType
	Color color.RGBA
}

// ScaleBy Method On Receiver ColoredPointType
//		i.e. Receiver Type Object Is Pass By Value
//		It's Taking One Argument
func ( point ColoredPointType ) ScaleBy( factor float64 ) {
	point.X = point.X * factor
	point.Y = point.Y * factor
}

// ScaleBy Method On Receiver ColoredPointType Reference
//		i.e. Receiver Type Object Is Pass By Reference
//		It's Taking One Argument
func ( point *ColoredPointType ) ScaleByAgain( factor float64 ) {
	point.X = point.X * factor
	point.Y = point.Y * factor
}

func playWithColoredPointMethods() {
	red 	:= color.RGBA{ 255, 0, 0, 255 }
	blue 	:= color.RGBA{ 0, 255, 0, 255 }

	var point1 = ColoredPointType{ PointType{ 10, 20}, red }
	var point2 = ColoredPointType{ PointType{ 11, 22}, blue }

	distance := point1.Distance( point2.PointType )
	fmt.Println("Point Distance: ", distance )

	fmt.Println("point1 : ", point1 )
	point1.ScaleBy( 2 )
	fmt.Println("point1 : ", point1 )

	fmt.Println("point1 : ", point1 )
	point1.ScaleByAgain( 2 )
	fmt.Println("point1 : ", point1 )
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithPointType");
	playWithPointType()

	fmt.Println("\nFunction: playWithFunctionsAndMethods");
	playWithFunctionsAndMethods()

	fmt.Println("\nFunction: playWithColoredPointMethods");
	playWithColoredPointMethods()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

