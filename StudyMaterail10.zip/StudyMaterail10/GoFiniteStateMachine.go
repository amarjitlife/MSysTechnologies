
package main

import "fmt"

type ServerState int

const (
	StateIdle = iota
	StateConnected
	StateError
	StateRetrying
)

var stateName = map[ServerState]string {
	StateIdle: "Idle State",
	StateConnected: "Connected State",
	StateError: "Error State",
	StateRetrying: "Retrying State",
}

// Methods
func (ss ServerState ) String() string {
	return stateName[ss]
}

func serverStateMachine( ss ServerState ) ServerState {
	switch  ss  {
	case StateIdle:
		return StateConnected
	case StateConnected, StateRetrying:
		return StateIdle
	case StateError:
		return StateError
	default:
		panic( fmt.Errorf("Unknown State: %s", ss))
	}

	return StateConnected
}

func playWithFiniteStateMachine() {
	newState := serverStateMachine( StateIdle )
	fmt.Println( newState )

	newState = serverStateMachine( newState )
	fmt.Println( newState )
}

func main() {
	playWithFiniteStateMachine()
}