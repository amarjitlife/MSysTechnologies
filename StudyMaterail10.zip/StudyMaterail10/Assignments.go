_______________________________________________________________

DAY 01
_______________________________________________________________


	Go Environment Setup
	Go Warm Up
	Practice Go Code Done In Class
_______________________________________________________________

DAY 02
_______________________________________________________________

Assingment A1: Reading, Reasoning And Thinking Assignment
	Reference Book: The C Programming Language, 2nd Edition
			By Kernigham and Dennis Richie

		Chapter 02: Types, Operators and Expressions

	Referenc: Java Specfications Documentation
		Types and Ranges In Java

Assingment A2: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class

Assignment A3: Experimentatin and Design Discussion Assignment

		public class Experiments {
		    public static void main(String[] args) {
		        System.out.println(1.0 / 0.0); 
		        System.out.println(-1.0 / 0.0);
		        System.out.println(0.0 / 0.0);
		        System.out.println(2.0 - 1.1);       
		    }
		}

		Experiment Above Idea In C, Python and Go Laguange
		Reason Output Of Program 
		Discover Design Decisions In Various Language About This Idea
		Which One Is Better Design

_______________________________________________________________

DAY 03
_______________________________________________________________

Assingment A1: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class

Assignment A2: Reading/Walkthrough Assingments 
	GO Package Reference
		math Package 	:: https://pkg.go.dev/math
		strings Package :: https://pkg.go.dev/strings
		bytes Package 	:: https://pkg.go.dev/bytes

Assignment A3: Deeper Learning and Thinking Assignments [ OPTIONALS ]
	Float Point Arithmatics IEEE 754 Standards
	Unicode Standard 

_______________________________________________________________

DAY 04 AND DAY 05
_______________________________________________________________

Assingment A1: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class

Assignment A2: Reading/Walkthrough Assingments 
	GO Package Reference

Assignment A3: Deeper Learning and Thinking Assignments
	Chapter : Pointers And Array

	Reference Book: The C Programming Language, 2nd Edition
		By Kernigham and Dennis Richie

_______________________________________________________________

DAY 06
_______________________________________________________________

Assingment A1: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class

_______________________________________________________________

DAY 07
_______________________________________________________________

Assingment A1: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class


Assignment A2: Reading/Walkthrough Assingments 
	GO Package Reference
		JSON Package:: https://go.dev/blog/json

_______________________________________________________________

DAY 08
_______________________________________________________________

Assingment A1: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class


_______________________________________________________________

DAY 09-10
_______________________________________________________________

Assingment A1: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class

_______________________________________________________________
_______________________________________________________________
_______________________________________________________________
_______________________________________________________________
_______________________________________________________________

