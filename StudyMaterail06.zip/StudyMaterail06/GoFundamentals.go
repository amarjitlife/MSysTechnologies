
package main

import "fmt"

//__________________________________________________
// Function Taking No Argument and No Return Value
func helloWorld() {
	fmt.Println("Hello World!!!");
}


//__________________________________________________
// Function Taking One Argument and One Return Value

func fToC( f float64 ) float64 {
	return ( f - 32 ) * 5 / 9
}

func playWithFToC() {
	// const freezingF = 32.0
	// const boilingF =  212.0 

	const freezingF, boilingF =  32.0, 212.0 

	fmt.Printf("\n%g F = %g C", freezingF, fToC( freezingF)  )
	fmt.Printf("\n%g F = %g C", boilingF, fToC( boilingF)  )
}

//__________________________________________________
// Go Follows Strict Type System

// Naming Conventions For Identifiers
//		Generally Identifiers Follows Camel Cases Starting With Small Letters

//		Identifiers With First Alphabet Small 
//			These Are Local To Package

//		Identifiers With First Alphabet Capital 
//			These Are Exported From Package
//			Hence Can Be Accessed Using import Statement

// Celsius and Farenhiet Are Type Aliases
//		Treated As Distinguised Types

type Celsius float64
type Fahrenheit float64

const (
	AbsoluteZeroC Celsius = -273.15
	FreezingC 	 Celsius  = 0 
	BoilingC 	Celsius = 100
)

func CToF( c Celsius ) Fahrenheit { return Fahrenheit( c  * 9/5 + 32 ) }
func FToC( f Fahrenheit ) Celsius { return Celsius( ( f - 32 ) * 5 / 9 ) }

func playWithTypes() {
	fmt.Println( BoilingC - FreezingC )
	boilingF := CToF( BoilingC )

	fmt.Println( boilingF )

	// var something float64  = 10.10
	// invalid operation: something + BoilingC
	//	 	(mismatched types float64 and Celsius)
	// something = something +  BoilingC

	// invalid operation: AbsoluteZeroC + boilingF 
	// 			(mismatched types Celsius and Fahrenheit)
	// result := AbsoluteZeroC + boilingF

	// fmt.Println( boilingF+10.0 ) works , Does it do implicit conversion ?
}

//__________________________________________________

// BEST PRACTICE
//		ALL Variables Must Assigned Valid Values
//		Explicit Programming Is Better Than Implicit Programming

func playWithDataTypes() {
	var c, python, java bool
	var i int

	fmt.Println(c, python, java) // 	false false false
	fmt.Println( i ) // 0

	var ii, jj = 10, 20
	fmt.Println( ii, jj )

	// Comile Time Decision
	// 	1. Type Inferrencing From RHS
	//	2. Type Binding: Will Bind Interrred Type With LHS
	k := 3 // Python Style
	fmt.Println( k )

	some, some1, something := true, false, "Good!"
	fmt.Println(some, some1, something)

//	Compiler Technology
//		Usage Analysis
//			Dead Code

// ./GoFundamentals.go:101:6: u declared and not used
// ./GoFundamentals.go:102:6: v declared and not used
	// var u int16 = 10
	// var v int32 = 100

	// Go Is Strick Type System
	// invalid operation: u * v (mismatched types int16 and int32)
	// var z = u * v
}

//__________________________________________________

func playWithFormatSpecifiers() {
	c := FToC( 212.0 )

	fmt.Println( c )
	fmt.Printf("\n %v", c )
	fmt.Printf("\n %f", c )
	fmt.Printf("\n %g", c )
	fmt.Printf("\n %e", c )
}

// General:
// %v	the value in a default format
// 			when printing structs, the plus flag (%+v) adds field names
// %#v	a Go-syntax representation of the value
// %T	a Go-syntax representation of the type of the value
// %%	a literal percent sign; consumes no value

// Boolean:

// %t	the word true or false
// Integer:

// %b	base 2
// %c	the character represented by the corresponding Unicode code point
// %d	base 10
// %o	base 8
// %O	base 8 with 0o prefix
// %q	a single-quoted character literal safely escaped with Go syntax.
// %x	base 16, with lower-case letters for a-f
// %X	base 16, with upper-case letters for A-F
// %U	Unicode format: U+1234; same as "U+%04X"

// Floating-point and complex constituents:

// %b	decimalless scientific notation with exponent a power of two,
// 	in the manner of strconv.FormatFloat with the 'b' format,
// 	e.g. -123456p-78
// %e	scientific notation, e.g. -1.234456e+78
// %E	scientific notation, e.g. -1.234456E+78
// %f	decimal point but no exponent, e.g. 123.456
// %F	synonym for %f
// %g	%e for large exponents, %f otherwise. Precision is discussed below.
// %G	%E for large exponents, %F otherwise
// %x	hexadecimal notation (with decimal power of two exponent), e.g. -0x1.23abcp+20
// %X	upper-case hexadecimal notation, e.g. -0X1.23ABCP+20
// String and slice of bytes (treated equivalently with these verbs):

// %s	the uninterpreted bytes of the string or slice
// %q	a double-quoted string safely escaped with Go syntax
// %x	base 16, lower-case, two characters per byte
// %X	base 16, upper-case, two characters per byte
// Slice:

// %p	address of 0th element in base 16 notation, with leading 0x
// Pointer:

// %p	base 16 notation, with leading 0x
// The %b, %d, %o, %x and %X verbs also work with pointers,
// formatting the value exactly as if it were an integer.

//__________________________________________________
//
// REFERENCE LINK : https://pkg.go.dev/fmt
//__________________________________________________

func playWithMoreTypesAndDefaults() {
	var a int
	var i8 int8
	var ui8 uint8

	var f1 float32
	var f2 float64

	var s string

	var c1 complex64 	// Form a + ib where a and b are float32
	var c2 complex128   // Form a + ib where a and b are float64

	var b bool

	fmt.Printf("%d %d %d\n", a, i8, ui8)
	fmt.Printf("%f %f\n", f1, f2)	
	fmt.Printf("%s \n", s)	
	fmt.Printf("%v %v", c1, c2)	
	fmt.Printf("%t \n", b)	
}

// 0 0 0
// 0.000000 0.000000
 
// (0+0i) (0+0i)false 


// Data Types In Go Language

// BEST PRACTICE
//	Explicit Programming Is Better Than Implicit Programming
//		Explicit Type Is Better Than Implicit Type

// 1. Integer Types
//		Signed int 		: int8, int16, int32, int64
//		Unsigned int 	: uint8, uint16, uint32, unint64

//		int, uint 		// Platform Dependent as well as Compiler
//							It's Range Can Be 32 Bit or 64 Bit

// 2. Floating Point Types 
//		float32 and float64
		
//		Why not here are Signed and Unsigned Flavors of Floating Point Data Types 
//			like int Type???
//		In C 
//			Single Precision Float Type Is float
//			Double Precision Float Type Is double
//		In Python
//			Single Precision Float Type Is Not Supported
//			Double Precision Float Type Is float

// 3. Complex Number Types
//		complex64 And complex128
//			complext64 Have Real and Imaginary Part of float32
//			complext128 Have Real and Imaginary Part of float64

// 4. String Type
//		Created Using Keyword string

//__________________________________________________

var pc [256]byte

func init() {
      for i := range pc {
            pc[i] = pc[i/2] + byte(i&1)
      }
}

func PopCount(x uint64) int {
      return int(pc[byte(x>>(0*8))] +
            pc[ byte(x >> (1*8)) ] +
            pc[ byte(x >> (2*8))] +
            pc[ byte(x >> (3*8))] +
            pc[ byte(x >> (4*8))] +
            pc[ byte(x >> (5*8))] +
            pc[ byte(x >> (6*8))] +
            pc[ byte(x >> (7*8))])
}

func BitCount(x uint64) int {
      // Hacker's Delight, Figure 5-2.
      x = x - ((x >> 1) & 0x5555555555555555)
      x = (x & 0x3333333333333333) + ((x >> 2) & 0x3333333333333333)
      x = (x + (x >> 4)) & 0x0f0f0f0f0f0f0f0f
      x = x + (x >> 8)
      x = x + (x >> 16)
      x = x + (x >> 32)
      return int( x & 0x7f )
}

func PopCountByClearing(x uint64) int {
      n := 0
      for x != 0 {
            x = x & (x - 1) // clear rightmost non-zero bit
            n++
      }
      return n
}

func PopCountByShifting(x uint64) int {
      n := 0
      for i := uint(0); i < 64; i++ {
            if x&(1 << i) != 0 {
                  n++
            }
      }
      return n
}

// func BenchmarkPopCount(b *testing.B) {
//       for i := 0; i < b.N; i++ {
//             PopCount(0x1234567890ABCDEF)
//       }
// }

// func BenchmarkBitCount(b *testing.B) {
//       for i := 0; i < b.N; i++ {
//             BitCount(0x1234567890ABCDEF)
//       }
// }

// func BenchmarkPopCountByClearing(b *testing.B) {
//       for i := 0; i < b.N; i++ {
//             PopCountByClearing(0x1234567890ABCDEF)
//       }
// }

// func BenchmarkPopCountByShifting(b *testing.B) {
//       for i := 0; i < b.N; i++ {
//             PopCountByShifting(0x1234567890ABCDEF)
//       }
// }

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: helloWorld");
	helloWorld();

	fmt.Println("\nFunction: playWithFToC");
	playWithFToC()

	fmt.Println("\nFunction: playWithTypes");
	playWithTypes()

	fmt.Println("\nFunction: playWithDataTypes");
	playWithDataTypes()

	fmt.Println("\nFunction: playWithFormatSpecifiers");
	playWithFormatSpecifiers()

	fmt.Println("\nFunction: playWithMoreTypesAndDefaults");
	playWithMoreTypesAndDefaults()
	
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}


