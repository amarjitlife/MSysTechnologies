
public class Experiments {
    public static void main(String[] args) {
//        90.90 Type Will be Inferred Double

        System.out.println( 1.0 / 0.0 ); 
        System.out.println( -1.0 / 0.0 );
        System.out.println( 0.0 / 0.0 );
        System.out.println( 2.0 - 1.1 );       

        // BAD CODE
        System.out.println(1.0 / 0.0    == Double.POSITIVE_INFINITY); 
        System.out.println(-1.0 / 0.0   == Double.NEGATIVE_INFINITY);
        
        System.out.println( (0.0 / 0.0) == Double.NaN );

        // GOOD CODE
        System.out.println(Double.isNaN(0.0 / 0.0));
// Infinity
// -Infinity
// NaN
// 0.8999999999999999
// true
// true
// false
    }
}

