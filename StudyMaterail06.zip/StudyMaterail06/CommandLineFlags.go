
package main

import (
	"flag"
	"fmt"
	"strings"
)

var n = flag.Bool("n", false, "Omit Trailing Newline")
var sep = flag.String("s", " ", "Seperator")

func main() {
	flag.Parse()

	fmt.Print( strings.Join( flag.Args(), *sep ))

	if !*n {
		fmt.Println()
	}
}


// Venkatesh Periyasamy (19 Jun 2024, 7:40 PM)
// fmt.Println( boilingF+10.0 ) works , Does it do implicit conversion ?
 
// suryakumar to You (direct message) (19 Jun 2024, 8:17 PM)
// Can you once explain what line number 18 does
 
// dominic (19 Jun 2024, 8:18 PM)
// If I send only flag it return empty 
// CmdArgFlag.go  -s aasa
// Is this expected
 
// Navin (19 Jun 2024, 8:18 PM)
// ./Flags -n 10 -s "as" -k "as"  is working without giving errors?

