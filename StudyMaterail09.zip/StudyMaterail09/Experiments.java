
//___________________________________________________________________

class NumberDemo {
    public static void playWithNumbers() {
//        90.90 Type Will be Inferred Double

        System.out.println( 1.0 / 0.0 ); 
        System.out.println( -1.0 / 0.0 );
        System.out.println( 0.0 / 0.0 );
        System.out.println( 2.0 - 1.1 );       

        // BAD CODE
        System.out.println(1.0 / 0.0    == Double.POSITIVE_INFINITY); 
        System.out.println(-1.0 / 0.0   == Double.NEGATIVE_INFINITY);
        
        System.out.println( (0.0 / 0.0) == Double.NaN );

        // GOOD CODE
        System.out.println(Double.isNaN(0.0 / 0.0));
// Infinity
// -Infinity
// NaN
// 0.8999999999999999
// true
// true
// false
    }
}

//___________________________________________________________________

interface Superpower {
    void fly();
    void saveWorld();
}

class Spiderman implements Superpower {
    public void fly()       { System.out.println("Fly Like Spiderman!"); }
    public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

class Superman implements Superpower {
    public void fly()       { System.out.println("Fly Like Superman!"); }
    public void saveWorld() { System.out.println("Save World Like Superman!"); }
}

class Wonderwoman implements Superpower {
    public void fly()       { System.out.println("Fly Like Wonderwoman!"); }
    public void saveWorld() { System.out.println("Save World Like Wonderwoman!"); }
}

class HanumanJi implements Superpower {
    public void fly()       { System.out.println("Fly Like HanumanJi!"); }
    public void saveWorld() { System.out.println("Save World Like HanumanJi!"); }
}

// class Human {
//     public void fly()       { System.out.println("Fly Like Human!"); }
//     public void saveWorld() { System.out.println("Save World Like Human!"); }
// }

// Using Inheritance Design
class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Wonderwoman {
    public void fly()       { super.fly();       }
    public void saveWorld() { super.saveWorld(); }
}

// Using Composition Design
//      Composition Equivalent To Inheritance
class HumanBetter  {
    Spiderman power = new Spiderman();
    public void fly()       { power.fly();       }
    public void saveWorld() { power.saveWorld(); }
}

class HumanBest  {
    Superpower power = null;
    public void fly()       { if (power != null) power.fly();       }
    public void saveWorld() { if (power != null) power.saveWorld(); }
}

// Fly Like Spiderman!
// Save World Like Spiderman!
// Fly Like Spiderman!
// Save World Like Spiderman!

class HumanDemo {
    public static void playWithHuman() {
        Human h = new Human();
        h.fly();
        h.saveWorld();

        HumanBetter better = new HumanBetter();
        better.fly();
        better.saveWorld();

        HumanBest best = new HumanBest();

        best.power = new Spiderman();
        best.fly();
        best.saveWorld();
    
        best.power = new Superman();
        best.fly();
        best.saveWorld();

        best.power = new Wonderwoman();
        best.fly();
        best.saveWorld();

        best.power = new HanumanJi();
        best.fly();
        best.saveWorld();        
    }
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________

public class Experiments {
    public static void main(String[] args) {
        System.out.println("\nFunction : playWithNumbers" );
        NumberDemo.playWithNumbers();

        System.out.println("\nFunction : playWithHuman" );
        HumanDemo.playWithHuman();

        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );
        // System.out.println("\nFunction :" );        
    }
}

