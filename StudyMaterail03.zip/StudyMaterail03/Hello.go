/*
1. Download Go Compiler Compressed File For Your OS and Architecture
2. Extract It
3. Add YOUR_FOLDER/go/bin Path in Path Variable

	In MacOSX/Linux Add Following Lines In Shell Profile File.
		
		GOPATH="/Users/intelligene/Documents/Softwares/go/bin"
		export PATH=$PATH:$GOPATH

	In Windows
		Add Path in PATH Environment Variable

4. Check Go Installation with Following Command
		go version
5A. Building Go Program
		go build Hello.go 

		Running Go Executable
		./Hello

	OR

5B. Running Go Programming Directly
		go run Hello.go
*/

package main

import "fmt"

func main() {
	fmt.Println("Hello World!!!");
}

