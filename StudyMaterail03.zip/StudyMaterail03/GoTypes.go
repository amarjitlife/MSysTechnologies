
package main

import (
	"fmt"
	"strings"
	"bytes"
)

//__________________________________________________

func playWithIfElse() {
	x := -10

	// if x {
	if x == -10 {
		fmt.Println("If Part")
	} else {
		fmt.Println("Else Part")
	}
}

func btoi( b bool ) int {
	if b { return 1 }
	return 0
}

func itob( i int ) bool {
	return i != 0
}

func playWithIfElseAgain() {
	x := -10

	if itob( x ) {
		fmt.Println("If Part")
	} else {
		fmt.Println("Else Part")
	}
}

//__________________________________________________

func basename( s string ) string {
	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {
			s = s[ i + 1 : ] // Slicing 
			break
		}
	}

	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '.' {
			s = s[ : i ] // Slicing
			break
		}
	}

	return s 
}

func basenameAgain( s string ) string {
	slash := strings.LastIndex( s, "/" )
	s = s[ slash + 1 : ] // Slicing

	if dot := strings.LastIndex( s, "." ) ; dot >= 0 {
		s = s[ : dot ] // Slicing
	}

	return s 
}

func playWithBaseName() {
	fmt.Println( basename("/home/amarjit/Documents/MSysTechnologies/Progress/GoTypes.go"))
	fmt.Println( basename("/home/amarjit/Documents/MSysTechnologies/Progress"))

	fmt.Println( basenameAgain("/home/amarjit/Documents/MSysTechnologies/Progress/GoTypes.go"))
	fmt.Println( basenameAgain("/home/amarjit/Documents/MSysTechnologies/Progress"))
}

// Function: playWithBaseName
// GoTypes
// Progress

//__________________________________________________
//
// GO Package Reference
// 		math Package 	:: https://pkg.go.dev/math
// 		strings Package :: https://pkg.go.dev/strings
//
//__________________________________________________
//__________________________________________________

// Recursive Function
func insertCommans( s string ) string {
	n := len( s )

	if n <= 3 { return s }
	return insertCommans( s[ : n - 3] ) + "," + s[ n - 3 : ]
}

func playWithInsertCommas() {
	fmt.Println( insertCommans( "123456789") )
	fmt.Println( insertCommans( "999") )
	fmt.Println( insertCommans( "56788") )
	fmt.Println( insertCommans( "893894839483948394839483948394394839") )
}

//_______________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE HANDS!!!

func intsToString( values []int ) string {
	// Creating Buffer of Bytes
	// A Buffer is a variable-sized buffer of bytes 
	// with Buffer.Read and Buffer.Write methods. 
	// The zero value for Buffer is an empty buffer ready to use.
	var buffer bytes.Buffer // It's Similar To StringBuilder() In Java

	buffer.WriteByte( '[' )

	// range Operator Will Enumerate List Of Values
	//		It Will Generate List Of Tuples 
	//			Every Tuple ( index, value )
	for i, v := range values {
		fmt.Printf(" %d ::  %v ", i, v )

		if i > 0 {
			buffer.WriteString( ", " )
		}
		fmt.Fprintf( &buffer, "%d", v )
	}

	buffer.WriteByte( ']' )
	// Converting Buffer To String
	return buffer.String()  // Similar To toString Function In Java
}

func playWithIntsToString() {
	fmt.Println( intsToString( []int{10, 20, 30}) )
	fmt.Println( intsToString( []int{10, 20, 99, 88, 77, 100}) )
	fmt.Println( intsToString( []int{11, 22, 33, 3000, 5000, 90000}) )
}

//__________________________________________________

// Following Code Experiment In Python Also
//		Tell Me What len() Function Retuns

// In Go Lang/Python/Java
//		String Is Uincode String

// In C/C++
//		String Is ASCII String

func playWithStringUnicode() {
    const sample = "\xbd\xb2\x3d\xbc\x20\xe2\x8c\x98"
    fmt.Println( sample )

    // In Go Lang
    //		len() Function Gives You Buffer Length In Bytes
    // In Python
    //		len() Function Gives You Number Unicode Characters
    fmt.Println( len( sample ) )    

    for i := 0 ; i < len( sample ) ; i++ {
    	fmt.Printf(" %x ", sample[i] )
    }
 
    const hello = "안녕하세요"
    fmt.Println( hello )

    const namaste = "नमस्ते"
    fmt.Println( namaste )

    const नम = "Hi!!!"
    fmt.Println( नम )

    fmt.Println( hello )
    fmt.Println( len( hello )  )

	 fmt.Println( namaste )
	 fmt.Println( len( namaste ) ) 
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithIfElse");
	playWithIfElse()

	fmt.Println("\nFunction: playWithIfElseAgain");
	playWithIfElseAgain()
	
	fmt.Println("\nFunction: playWithBaseName");
	playWithBaseName()

	fmt.Println("\nFunction: playWithInsertCommas");
	playWithInsertCommas()

	fmt.Println("\nFunction: playWithIntsToString");
	playWithIntsToString()

	fmt.Println("\nFunction: playWithStringUnicode");
	playWithStringUnicode()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}


