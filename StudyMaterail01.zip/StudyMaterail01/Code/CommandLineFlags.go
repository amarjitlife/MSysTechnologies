
package main

import (
	"flag"
	"fmt"
	"strings"
)

var n = flag.Bool("n", false, "Omit Trailing Newline")
var sep = flag.String("s", " ", "Seperator")

func main() {
	flag.Parse()

	fmt.Print( strings.Join( flag.Args(), *sep ))

	if !*n {
		fmt.Println()
	}
}

