
package main

import "fmt"

//__________________________________________________
// Function Taking No Argument and No Return Value
func helloWorld() {
	fmt.Println("Hello World!!!");
}


//__________________________________________________
// Function Taking One Argument and One Return Value

func fToC( f float64 ) float64 {
	return ( f - 32 ) * 5 / 9
}

func playWithFToC() {
	// const freezingF = 32.0
	// const boilingF =  212.0 

	const freezingF, boilingF =  32.0, 212.0 

	fmt.Printf("\n%g F = %g C", freezingF, fToC( freezingF)  )
	fmt.Printf("\n%g F = %g C", boilingF, fToC( boilingF)  )
}

//__________________________________________________
// Go Follows Strict Type System

// Naming Conventions For Identifiers
//		Generally Identifiers Follows Camel Cases Starting With Small Letters

//		Identifiers With First Alphabet Small 
//			These Are Local To Package

//		Identifiers With First Alphabet Capital 
//			These Are Exported From Package
//			Hence Can Be Accessed Using import Statement

// Celsius and Farenhiet Are Type Aliases
//		Treated As Distinguised Types

type Celsius float64
type Fahrenheit float64

const (
	AbsoluteZeroC Celsius = -273.15
	FreezingC 	 Celsius  = 0 
	BoilingC 	Celsius = 100
)

func CToF( c Celsius ) Fahrenheit { return Fahrenheit( c  * 9/5 + 32 ) }
func FToC( f Fahrenheit ) Celsius { return Celsius( ( f - 32 ) * 5 / 9 ) }

func playWithTypes() {
	fmt.Println( BoilingC - FreezingC )
	boilingF := CToF( BoilingC )

	fmt.Println( boilingF )

	// var something float64  = 10.10
	// invalid operation: something + BoilingC
	//	 	(mismatched types float64 and Celsius)
	// something = something +  BoilingC

	// invalid operation: AbsoluteZeroC + boilingF 
	// 			(mismatched types Celsius and Fahrenheit)
	// result := AbsoluteZeroC + boilingF

	// fmt.Println( boilingF+10.0 ) works , Does it do implicit conversion ?
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: helloWorld");
	helloWorld();

	fmt.Println("\nFunction: playWithFToC");
	playWithFToC()

	fmt.Println("\nFunction: playWithTypes");
	playWithTypes()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}


