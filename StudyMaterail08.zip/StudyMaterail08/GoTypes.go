
package main

import (
	"fmt"
	"strings"
	"bytes"
	"strconv"
)

//__________________________________________________

func playWithIfElse() {
	x := -10

	// if x {
	if x == -10 {
		fmt.Println("If Part")
	} else {
		fmt.Println("Else Part")
	}
}

func btoi( b bool ) int {
	if b { return 1 }
	return 0
}

func itob( i int ) bool {
	return i != 0
}

func playWithIfElseAgain() {
	x := -10

	if itob( x ) {
		fmt.Println("If Part")
	} else {
		fmt.Println("Else Part")
	}
}

//__________________________________________________

func basename( s string ) string {
	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {
			s = s[ i + 1 : ] // Slicing 
			break
		}
	}

	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '.' {
			s = s[ : i ] // Slicing
			break
		}
	}

	return s 
}

func basenameAgain( s string ) string {
	slash := strings.LastIndex( s, "/" )
	s = s[ slash + 1 : ] // Slicing

	if dot := strings.LastIndex( s, "." ) ; dot >= 0 {
		s = s[ : dot ] // Slicing
	}

	return s 
}

func playWithBaseName() {
	fmt.Println( basename("/home/amarjit/Documents/MSysTechnologies/Progress/GoTypes.go"))
	fmt.Println( basename("/home/amarjit/Documents/MSysTechnologies/Progress"))

	fmt.Println( basenameAgain("/home/amarjit/Documents/MSysTechnologies/Progress/GoTypes.go"))
	fmt.Println( basenameAgain("/home/amarjit/Documents/MSysTechnologies/Progress"))
}

// Function: playWithBaseName
// GoTypes
// Progress

//__________________________________________________
//
// GO Package Reference
// 		math Package 	:: https://pkg.go.dev/math
// 		strings Package :: https://pkg.go.dev/strings
//
//__________________________________________________
//__________________________________________________

// Recursive Function
func insertCommans( s string ) string {
	n := len( s )

	if n <= 3 { return s }
	return insertCommans( s[ : n - 3] ) + "," + s[ n - 3 : ]
}

func playWithInsertCommas() {
	fmt.Println( insertCommans( "123456789") )
	fmt.Println( insertCommans( "999") )
	fmt.Println( insertCommans( "56788") )
	fmt.Println( insertCommans( "893894839483948394839483948394394839") )
}

//_______________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE HANDS!!!

func intsToString( values []int ) string {
	// Creating Buffer of Bytes
	// A Buffer is a variable-sized buffer of bytes 
	// with Buffer.Read and Buffer.Write methods. 
	// The zero value for Buffer is an empty buffer ready to use.
	var buffer bytes.Buffer // It's Similar To StringBuilder() In Java

	buffer.WriteByte( '[' )

	// range Operator Will Enumerate List Of Values
	//		It Will Generate List Of Tuples 
	//			Every Tuple ( index, value )
	for i, v := range values {
		fmt.Printf(" %d ::  %v ", i, v )

		if i > 0 {
			buffer.WriteString( ", " )
		}
		fmt.Fprintf( &buffer, "%d", v )
	}

	buffer.WriteByte( ']' )
	// Converting Buffer To String
	return buffer.String()  // Similar To toString Function In Java
}

func playWithIntsToString() {
	fmt.Println( intsToString( []int{10, 20, 30}) )
	fmt.Println( intsToString( []int{10, 20, 99, 88, 77, 100}) )
	fmt.Println( intsToString( []int{11, 22, 33, 3000, 5000, 90000}) )
}

//__________________________________________________

// Following Code Experiment In Python Also
//		Tell Me What len() Function Retuns

// In Go Lang/Python/Java
//		String Is Uincode String

// In C/C++
//		String Is ASCII String

func playWithStringUnicode() {
    const sample = "\xbd\xb2\x3d\xbc\x20\xe2\x8c\x98"
    fmt.Println( sample )

    // In Go Lang
    //		len() Function Gives You Buffer Length In Bytes
    // In Python
    //		len() Function Gives You Number Unicode Characters
    fmt.Println( len( sample ) )    

    for i := 0 ; i < len( sample ) ; i++ {
    	fmt.Printf(" %x ", sample[i] )
    }
 
    const hello = "안녕하세요"
    fmt.Println( hello )

    const namaste = "नमस्ते"
    fmt.Println( namaste )

    const नम = "Hi!!!"
    fmt.Println( नम )

    fmt.Println( hello )
    fmt.Println( len( hello )  )

	 fmt.Println( namaste )
	 fmt.Println( len( namaste ) ) 
}

//__________________________________________________

func playWithStringType() {
	s := "Hello World!"

	fmt.Println( s )
	fmt.Println("String Length: ", len( s ) )

	s1 := "Hello World!\uD55C" // 한

	fmt.Println( s1 )
	fmt.Println("String Length: ", len( s1 ) )

	s2 := "Hello World!\u1112\u1161\u11AB" // 한

	fmt.Println( s2 )
	fmt.Println("String Length: ", len( s2 ) )

	fmt.Println( s2[0], s2[7], s2[19]  )	

	fmt.Println( s[ 0 : 5 ])
	fmt.Println( s[ : 5 ] )
	fmt.Println( s[ 7 : ] )
	fmt.Println( s[ : ] )

	ss := "Left Foot"
	tt := ss
	fmt.Println( tt )
	ss += " and Right Foot"
	fmt.Println( ss )

	// ss[0] = "X"
}

// Function: playWithStringType
// Hello World!
// String Length:  12
// Hello World!한
// String Length:  15

//__________________________________________________

func playWithStringsFunctions() {

    fmt.Println("Contains:  ", strings.Contains("test", "es"))
    fmt.Println("Count:     ", strings.Count("test", "t"))
    fmt.Println("HasPrefix: ", strings.HasPrefix("test", "te"))
    fmt.Println("HasSuffix: ", strings.HasSuffix("test", "st"))
    fmt.Println("Index:     ", strings.Index("test", "e"))
    fmt.Println("Join:      ", strings.Join([]string{"a", "b"}, "-"))
    fmt.Println("Repeat:    ", strings.Repeat("a", 5))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", -1))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", 1))
    fmt.Println("Split:     ", strings.Split("a-b-c-d-e", "-"))
    fmt.Println("ToLower:   ", strings.ToLower("TEST"))
    fmt.Println("ToUpper:   ", strings.ToUpper("test"))
}

//__________________________________________________

// In Go Language
	// A string is an immutable sequence of bytes. 
	// Strings may contain arbitrary data, including bytes with value 0, 
	// but usually they contain human-readable text. 

	// Text strings are conventionally interpreted as UTF-8-encoded 
	// sequences of Unicode code points (runes)
	// It Stores Unicode Characters

	// Internal Structure Of string Type In Go Langauge

		// type _string struct {
		// 		elements *byte // underlying bytes
		// 		len      int   // number of bytes
		// }

// The built-in len function returns the number of bytes (not runes) 
// in a string, and the index operation s[i] retrieves the i-th 
// byte of string s, where 0 ≤ i < len(s).

// The i-th byte of a string is not necessarily the i-th character 
// of a string, because the UTF-8 encoding of a non-ASCII code point 
// requires two or more bytes.

// In C Language
	// There Is No String Type In C
	// String Value Denoted By ""
	// String Is Sequence Of ASCII Characters Stored In char Type Array
	// In C
	//		String Follows ASCII Coding
	//		String Ends With '\0' Null ASCII Character In Memory

//__________________________________________________

func playWithStringUnicodeAgain() {
	const something = `⌘`

	fmt.Printf("Plain String: ")
	fmt.Printf("%s", something)
	fmt.Println()

	fmt.Printf("Plain String: ")
	fmt.Printf("%q", something)
	fmt.Println()

	fmt.Printf("Hex Bytes:")
	for i := 0 ; i < len( something ) ; i++ {
		fmt.Printf( " %x ", something[i] )
	}
	fmt.Println()

// For `⌘` Unicode Points Are 
// 		UTF-8 Encoding:	0xE2 0x8C 0x98

	somethingAgain := "Hello, 한瘔"
	fmt.Println( somethingAgain )
	fmt.Println( len( somethingAgain ) )
	fmt.Printf("Hex Bytes: ")
	for i := 0 ; i < len( somethingAgain ) ; i++ {
		fmt.Printf(" %x ", somethingAgain[i] )
	}

// utf8 Unicode Encoding Is Backward Compatible With ASCII
// Hello, 한瘔
// 13
// Hex Bytes:  48  65  6c  6c  6f  2c  20  ed  95  9c  e7  98  94 

	fmt.Println()	

	for index, character := range somethingAgain {
		fmt.Printf("\n %d :: %q :: %x", index, character, character)
	}

	for _, character := range somethingAgain {
		fmt.Printf("\n%q :: %x", character, character)		
	}

	characterCount := 0
	for _, _ = range somethingAgain {
		characterCount++
	}
	fmt.Println("\nUnicode Character Count: ", characterCount )

	characterCount = 0
	for range somethingAgain {
		characterCount++
	}
	fmt.Println("\nUnicode Character Count: ", characterCount )


	x := 123
	y := fmt.Sprintf( "%d", x )
	fmt.Println( y )

	fmt.Println( strconv.Itoa( x ) )
	fmt.Println( strconv.Atoi( "898980"))
}

// Function: playWithStringUnicodeAgain
// Plain String: ⌘
// Plain String: "⌘"
// Hex Bytes: e2  8c  98 

//__________________________________________________

const (
	a = 1
	b
	c = 2
	d
)

const (
	aa = 1
	bb = 2
	cc = 3
	dd = 4
)

const (
	aaa = iota // iota Starts From 0 Value
	bba = iota
	cca = iota
	dda = iota
)

const (
	aab = iota // iota Starts From 0 Value
	bbb
	ccb
	ddb
)

func playWithConsts() {
	fmt.Println( a )
	fmt.Println( b )
	fmt.Println( c )
	fmt.Println( d )	

	fmt.Println( aa )
	fmt.Println( bb )
	fmt.Println( cc )
	fmt.Println( dd )	

	fmt.Println( aaa )
	fmt.Println( bba )
	fmt.Println( cca )
	fmt.Println( dda )	

	fmt.Println( aab )
	fmt.Println( bbb )
	fmt.Println( ccb )
	fmt.Println( ddb )	
}

//__________________________________________________

const (
	aac = 1 << iota // 1 = 2^0  // iota = 0
	bbc = 1 << iota // 2 = 2^1  // iota = 1
	ccc = 1 << iota // 4 = 2^2  // iota = 2
	// ddc = 1 << iota // 8 	// iota = 3
	ddc = 3   					// iota = 3
	eec = 1 << iota // 16 		// iota = 4
)

const (
	u 			= iota * 42
	v float64 	= iota * 42
	w 			= iota * 42
)

const x = iota
const y = iota 

func playWithConstsAgain() {
	fmt.Println( aac )
	fmt.Println( bbc )
	fmt.Println( ccc )
	fmt.Println( ddc )
	fmt.Println( eec )

	fmt.Println( u, v, w )
	fmt.Println( x, y )
}

//__________________________________________________

type Weekday int

const (
	Sunday Weekday = iota   // iota = 0
	Monday 					// iota = 1 
	Tuesday
	Wednesday
	Thursday
	Friday
	Saturday
)

// In Java
// enum Weekday {
// 		Sunday, Monday, Tuesday, Weekday, Thursday, Friday, Saturday
// }

// In Java Usage Of Enum As Follows
// Weekday someDay = Weekday.Sunday

//__________________________________________________

const (
    _ = 1 << (10 * iota)  	// 10 Raised To Power 0
    KiB // 1024  		 	// 10 Raised To Power 1 i.e. 2^10
    MiB // 1048576
    GiB // 1073741824
    TiB // 1099511627776
    PiB // 1125899906842624
    EiB // 1152921504606846976
    ZiB // 1180591620717411303424
    YiB // 1208925819614629174706176
)

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithIfElse");
	playWithIfElse()

	fmt.Println("\nFunction: playWithIfElseAgain");
	playWithIfElseAgain()
	
	fmt.Println("\nFunction: playWithBaseName");
	playWithBaseName()

	fmt.Println("\nFunction: playWithInsertCommas");
	playWithInsertCommas()

	fmt.Println("\nFunction: playWithIntsToString");
	playWithIntsToString()

	fmt.Println("\nFunction: playWithStringUnicode");
	playWithStringUnicode()

	fmt.Println("\nFunction: playWithStringType");
	playWithStringType()

	fmt.Println("\nFunction: playWithStringsFunctions");
	playWithStringsFunctions()

	fmt.Println("\nFunction: playWithStringUnicodeAgain");
	playWithStringUnicodeAgain()

	fmt.Println("\nFunction: playWithConsts");
	playWithConsts()

	fmt.Println("\nFunction: playWithConstsAgain");
	playWithConstsAgain()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}


