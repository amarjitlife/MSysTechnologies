
package main

import (
	"fmt"
	"log"
	"errors"
)


//__________________________________________________

// Function Returns Tuple Of Two Values
func division( dividend, divisor int ) ( int, int ) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder 
	} else {
		// fmt.Println("Error: Division By Zero!")
		log.Fatalf("JSON UNMarshalling Failed! %s", "DividByZeroError" )	
	}
	return 0, 0
}

// Function Returns Tuple Of Two Values
func divisionAgain( dividend, divisor int ) ( quotient int, remainder int ) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder 
	} else {
		// fmt.Println("Error: Division By Zero!")
		log.Fatalf("Division Failed! %s", "DividByZeroError" )	
	}
	return 0, 0
}

func divisionMore( dividend, divisor int ) ( int, int, error ) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder, nil 
	} else {
		// fmt.Println("Error: Division By Zero!")
		// log.Fatalf("Division Failed! %s", "DividByZeroError" )	
		return 0, 0, errors.New("DivideByZeroError") 
	}
}

func playWithDivision() {
	q, r := division( 10, 3 )
	fmt.Printf("\nQuotient: %d, Remainder: %d", q, r )

	qq, rr := divisionAgain( 10, 3 )
	fmt.Printf("\nQuotient: %d, Remainder: %d", qq, rr )

	qqq, rrr, error := divisionMore( 10, 0 )

	// fmt.Println( error )
	if error == nil {
		fmt.Printf("\nQuotient: %d, Remainder: %d", qqq, rrr )
	} else {
		fmt.Printf("\nError Happened: %s", error )
	}
}

//__________________________________________________

func dummyFunction( ) ( int, int, int, int, int, string ) {
	return 10, 20, 30, 40, 50, "Good Evening!"
}

var globalVariable int = 100

func playWithDummyFunction() {
	a, b, c, d, e, greeting := dummyFunction()

	fmt.Println(a, b, c, d, e, greeting)

	globalVariable = globalVariable + 100
	fmt.Println( globalVariable )
}

//__________________________________________________

func playWithClosures() {
	var x, y = 30, 10

	// Lambda/Closures Functions
	//		Anonmous Functions i.e. Functions Without Name
	add := func(x, y int) int { return x + y }
	sub := func(x, y int) int { return x - y }

	result := add(x, y)
	fmt.Println("Result : ", result )

	result = sub(x, y)
	fmt.Println("Result : ", result )

	start := 0

	incrementBy7 := func() int {
		start = start + 7
		return start
	}

	incrementBy10 := func() int {
		start = start + 10
		return start
	}

	result = incrementBy7()
	fmt.Println("incrementBy7 Result: ", result )

	result = incrementBy7()
	fmt.Println("incrementBy7 Result: ", result)

	result = incrementBy7()
	fmt.Println("incrementBy7 Result: ", result)

	result = incrementBy7()
	fmt.Println("incrementBy7 Result: ", result)

	result = incrementBy10()
	fmt.Println("incrementBy10 Result: ", result)

	result = incrementBy10()
	fmt.Println("incrementBy10 Result: ", result)
}


//__________________________________________________

// Polymorphic Function
//		Mechanism: Using Passing Behaviour To Behaviour

// Higher Order Functions
//		Functions Taking and/or Return Functions/Closures

// Function Type Of calculator
//		func(int, int,  func(int, int) int ) int
func calculator(x int, y int, operation func(int, int) int ) int {
	return operation(x, y)
}

// Function Type Of Followings
//		func(int, int) int
func summation( x int, y int ) int { return x + y }
func substraction( x int, y int ) int { return x - y }

// Function Type Of Followings
//		func(int, int, int) int
func summation3( x int, y int, z int ) int { return x + y + z}

func playWithCalculator() {
	var x, y = 30, 10

	// Lambda/Closures Functions
	//		Anonmous Functions i.e. Functions Without Name

	// Type Of Following Closures
	//		func(int, int) int

	add := func(x, y int) int { return x + y }
	sub := func(x, y int) int { return x - y }
	mul := func(x, y int) int { return x * y }
	div := func(x, y int) int { return x / y }

	add3 := func(x, y, z int) int { return x + y + z }

	// Pasing Behvaiour To Behaviour
	result := calculator(x, y, add)
	fmt.Println("Result : ", result )

	result = calculator(x, y, sub)
	fmt.Println("Result : ", result )

	result = calculator(x, y, mul)
	fmt.Println("Result : ", result )

	result = calculator(x, y, div)
	fmt.Println("Result : ", result )

	//cannot use add3 (variable of type func(x int, y int, z int) int) 
	// as func(int, int) int value in argument to calculator
	result = add3(10, 20, 30)
	// result = calculator(x, y, add3)
	// fmt.Println("Result : ", result )	

	result = calculator(x, y, summation)
	fmt.Println("Result : ", result )		

	var something = summation
	result = something( 100, 200 )
	fmt.Println("Result : ", result )		

	// cannot use summation3 (value of type func(x int, y int, z int) int) 
	// as func(x int, y int) int value in assignment
	// something = summation3

	var somethingAgain func(int, int) int
	somethingAgain = substraction

	result = somethingAgain( 300, 100 )
	fmt.Println("Result : ", result )		
}


//__________________________________________________

func firstFunction() {
	fmt.Println("First Function Called...")
}

func secondFunction() {
	fmt.Println("Second Function Called...")
}

func playWithFunctionsDefer() {
	defer firstFunction()
	secondFunction()
}

//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithDivision");
	playWithDivision()

	fmt.Println("\nFunction: playWithDummyFunction");
	playWithDummyFunction()

	fmt.Println("\nFunction: playWithClosures");
	playWithClosures()

	fmt.Println("\nFunction: playWithCalculator");
	playWithCalculator()

	fmt.Println("\nFunction: playWithFunctionsDefer");
	playWithFunctionsDefer()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

