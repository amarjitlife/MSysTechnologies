
____________________________________________________________________

WRITE FOLLOWING sum Function With In C Language

int sum(int x, int y) 

____________________________________________________________________

// DESIGN 01
int sum( x int, y int )  {
       return x + y 
}


// DESIGN 02
int sum(int a, int b) {
	if( a < Int_max && a > Int_min ) && b < Int_max && b > Int_min )
		return a + b;
	else // DEAD CODE
		return -1;
}


// DESIGN 03
int sum(int x , int y){
  try:
     int c  = x + y
     return c;
  Catch :
     print(”Can’t calculate”)
}


// DESIGN 04
#include<limits.h>
int sum(int a,int b){
    if (a<INT_MAX && a>INT_MIN && b<INT_MAX && b>INT_MIN && 
    	a+b<INT_MAX && a+b > INT_MIN)
      return a+b ;
    else // DEAD BREANCH
      return -1;
}


// DESIGN 05
int sum(int x, int y){
  int z=0;
  z=x+y;
  if (z.isInt() || errno==0)
     return z;
  else
     return -1;
}

// DESIGN 06
int sum(int x,int y){
If (x < INT_MAX && x> INT_MIN) && (y < INT_MAX && y > INT_MIN)
	{
		int sum= x+y;
		If (sum < INT_MAX && sum> INT_MIN)
			return sum;
		else
			printf(“Cant Calculate Sum For Given Values”)
}


//DESIGN 07: GOOD DESIGN
int sum ( int x , int y) {
	// Type Safe Code
	if ((x > 0 && y > max -x ) || (x < 0 && y < min -x )) {
			return 0;
			print(“can’t calculate sum of given values”)
	}
	return x + y;
}

Int sum(int x, int y){
	if(x > 0 && x > INT_MAX - y) || (y > 0 && x < INT_MAX - y)
			Return x + y;
}

NAME: Venkatesh
CODE: 
int sum(int x, int y) {
    if(x+y<=INT_MAX)
        return x+y;
    else
        printf("Can't sum on the given value");
}


NAME: Dhanu Prabha
CODE:
int sum(int x, int y) {
    if ((y > INT_MIN && x > INT_MAX - y) || (y < INT_MIN && x < INT_MIN - y)){
    	  return -1
    }	
    return x + y;
}

int main() {
    int a = 5, b = 10;
    int result = sum(a, b);
    If (result == -1){
       printf("Sum of %d and %d is %d", a, b, result);
    }else{
      printf("Sum of %d and %d is %d", a, b, result);
    }
}


NAME:Dominic
CODE:
int sum(int x, int y) {
	if(
(x < int_min || x > int_max ) && (y < int_min || y > int_max ) 	
( y > int_min && (x > int_max - y)) &&
( y < int_max && (x < int_min - y)
)
		Return -1 
	Else 
Return X + Y
	
}






NAME: SuryaKumar
CODE:
int sum(int x, int y) {

        return ( x + y )
}


NAME:
CODE:

NAME:Murugan
CODE:
int sum(int x, int y,  int total) {
    z=x+y
    If(total==z){
        return z
    }
    else{
     printf(“invalid inputs”)
    }
}


NAME:Pavan 
CODE:
int sum(int x,int y)
{
   int z = 0;
  if( (x > 0 && x < INT_MAX) || (y > 0 && y < INT_MAX)
 {
   Z = x + y;
 }
 else
 {
  return -1;
 }
}

NAME:Rajkumar
CODE:int sum(int x,int y) {
	return x+y;
}

NAME: Raj Kumar B
CODE: int sum(int x, int y) {
    if ((y > 0 && x > INT_MAX - y) || (y < 0 && x < INT_MIN - y)){
    	  return -1
    }	
    return x + y;
}


NAME:
CODE:

NAME:
CODE:

NAME:Sridharshini
CODE:int a=7,b=5,result
     result = a+b
     printf(“THE SUM IS %d:”, result)

    int sum(int x, int y){ return x+y;}
    ''
    Int sum(int x, int y)
    {
     Int result;
     
     if((x < max && x > min) && (y < max && y > min) && ((x+y) < max && (x+y)> min)) {return x+y;}
Else{return “Invalid Input”}
}
NAME:Kiruthika
CODE:int sum(int x, int y){
if (x <= INT_MAX && x>= INT_MIN) &&   (y <= INT_MAX && y>= INT_MIN) 
Return x + y 
}
Int main (){
Result = sum ()


NAME: Subhalaxmi
CODE: int x,y,z
      z=x+y
      printf(z)

NAME:
CODE:

NAME:
CODE:

NAME:
CODE:

NAME:Kokila
CODE:

int sum(int x, int y){
  If ( x < intmax) || (y < intMax){

  return x + y;
}


NAME:
CODE:

NAME:Naresh
CODE:int sum(int x, int y) {
	return x + y;
}

NAME: Rahul kumar
CODE: int sum (int a, int b) {
		Return a+b
}

NAME:Nilesh Gaikwad
CODE:
int sum(int a, int b) {
try {
       return a+b;
      }
      catch exception {
       return -1
      }
     }


