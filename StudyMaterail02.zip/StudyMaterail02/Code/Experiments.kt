
package learnKotlin

fun playWithTypes() {
	var i: Int
	var c: Boolean

	i = 1000
	println(i)
	println(c)
}

fun main(args: [String]) {
	playWithTypes()
}

