_______________________________________________________________

DAY 01
_______________________________________________________________


	Go Environment Setup
	Go Warm Up
	Practice Go Code Done In Class
_______________________________________________________________

DAY 02
_______________________________________________________________

Assingment A1: Reading, Reasoning And Thinking Assignment
	Reference Book: The C Programming Language, 2nd Edition
			By Kernigham and Dennis Richie

		Chapter 02: Types, Operators and Expressions

	Referenc: Java Specfications Documentation
		Types and Ranges In Java

Assingment A2: Go Coding, Revision and Experimentation
	Practice Code and Ideas Discussed In Class

Assignment A3: Experimentatin and Design Discussion Assignment

		public class Experiments {
		    public static void main(String[] args) {
		        System.out.println(1.0 / 0.0); 
		        System.out.println(-1.0 / 0.0);
		        System.out.println(0.0 / 0.0);
		        System.out.println(2.0 - 1.1);       
		    }
		}

		Experiment Above Idea In C, Python and Go Laguange
		Reason Output Of Program 
		Discover Design Decisions In Various Language About This Idea
		Which One Is Better Design

_______________________________________________________________

DAY 03
_______________________________________________________________


_______________________________________________________________

DAY 04
_______________________________________________________________


_______________________________________________________________

DAY 05
_______________________________________________________________


