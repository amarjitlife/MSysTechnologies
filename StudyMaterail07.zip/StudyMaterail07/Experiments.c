
#include <stdio.h>

//__________________________________________________

void playWithPointers() {
	int some = 100;
	// Assigning Address Of some Using & Operator
	int * pointer = &some;

	int value = *pointer;

	printf("\n Value: %d", some );
	printf("\n Address: %p", pointer );
	printf("\n Value At Pointer : %d", value );

	int **pointerToPointer = &pointer;
	printf("\n Value At Pointer : %d", **pointerToPointer );
}

//__________________________________________________

// int sum(int a, int b) { return a + b; }

void changeArray( int someArray[] ) {
	for ( int  i = 0 ; i < 5 ; i++ ) {
		someArray[i] = 777;
	}
}

void playWithArraysAndPointers() {
	// UserName and Password
	int aa[5] = {10, 20, 30, 40, 50};

	// int k = sum(a, b);

	for ( int  i = 0 ; i < 10 ; i++ ) {
		// if ( i > 0 && i < 5 ) {
		printf("\n %d", aa[i] );
		// } else {
		// 	//Throw IndexOutofBoundException
		// }
	}

	int *ptr = aa;
	for ( int  i = 0 ; i < 10 ; i++ ) {
		printf("\n %d", * ( ptr + i ) );
	}

	// aa Is Address OF Contigous Memory Location
	// 		aa Is Pass By Value
	//		aa Reference OF Continous Memory Location [ARRAY]
	//		Array Is Pass By Reference
	changeArray( aa );
	for ( int  i = 0 ; i < 5 ; i++ ) {
		printf("\n %d", aa[i] );
	}	
}

//__________________________________________________

typedef struct human_type {
	int id;
 	char name[100];
 	void (*dance)();

} Human;

void doBhangra() {
	printf("\nOyee Hoyee... Balleee Baalleee...");
}

void doHipHop() {
	printf("\nDoing Hip Hop Dance...");
}

void playWithHuman() {
					// Constructor 
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\n ID    : %d", gabbar.id );
	printf("\n NAME  : %s", gabbar.name );	
	gabbar.dance();

	Human basanti = { 111, "Basanti", doHipHop };

	printf("\n ID    : %d", basanti.id );
	printf("\n NAME  : %s", basanti.name );		
	basanti.dance();
}


//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\nFunction : playWithPointers");
	playWithPointers();

	printf("\nFunction : playWithArraysAndPointers");
	playWithArraysAndPointers();

	printf("\nFunction : playWithHuman");
	playWithHuman();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	return 0;
}

