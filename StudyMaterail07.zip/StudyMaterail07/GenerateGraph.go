
package main

import (
	"fmt"
	"math"
)

const (
	width, height = 600, 320
	cells = 100
	xyrange = 30.0
	xyscale = width / 2 / xyrange
	zscale = height * 0.4
	angle = math.Pi / 6
)

var sin30, cos30 = math.Sin(angle), math.Cos(angle)

// Function Takes Two int Type Argument and Returns A Tuple Of float64 Type Value
// Following Both Signatures Are Equivalent
// func corner( i int, j int) ( float64, float64 ) {	
func corner( i, j int) ( float64, float64 ) {	
	//	Finding Poing (x,y) At Corner Of Cell (i, j)
	x := xyrange * ( float64(i) / cells - 0.5 )
	y := xyrange * ( float64(j) / cells - 0.5 )

	// Compute Surface Height z
	//1. Type Inferrencing Form RHS
	//2. Type Binding To LHS i.e. Inferred Type Is Binded To LHS

	z := f(x, y)

	//1. Type Inferrencing Form RHS
	//2. Type Binding To LHS i.e. Inferred Type Is Binded To LHS
	sx := width/2 + (x-y)*cos30*xyscale
	sy := height/2 + (x+y)*sin30*xyscale - z*zscale

	return sx, sy
}

// Function Takes Two float64 Type Argument and Returns A float64 Type Value
// Following Both Signatures Are Equivalent
// func f(x float64, y float64) float64 {
func f(x, y float64) float64 {
	r := math.Hypot(x, y) // distance from (0,0)
	return math.Sin(r) / r
}

func playWithCanvas() {
	fmt.Printf("<svg xmlns='http://www.w3.org/2000/svg' "+
		"style='stroke: grey; fill: white; stroke-width: 0.7' "+
		"width='%d' height='%d'>", width, height)
	for i := 0; i < cells; i++ {
		for j := 0; j < cells; j++ {
			ax, ay := corner(i+1, j)
			bx, by := corner(i, j)
			cx, cy := corner(i, j+1)
			dx, dy := corner(i+1, j+1)
			fmt.Printf("<polygon points='%g,%g %g,%g %g,%g %g,%g'/>\n",
				ax, ay, bx, by, cx, cy, dx, dy)
		}
	}
	fmt.Println("</svg>")
}

func main() {
	playWithCanvas()
}

