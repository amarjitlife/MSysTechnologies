
package main

import (
	"fmt"
)

//__________________________________________________

func playWithArrays() {
	// Creating Array of 3 Ints
	//		Array Index Starts Frm 0 Till (len - 1)
	//		All The Elements Of Array Are Initialised 
	//			To Default Values Of Type
	//			int Type Default Vlaue 0
	var a [3]int

	fmt.Printf("\nData Type: %T", a )

	for index, value := range a {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[ len( a ) - 1 ] )

	// Compiler Time Error
	// ./GoCompositeTypes.go:25:18: invalid argument: index 3 out of bounds [0:3]
	// fmt.Println( a[ len( a ) ] )

	for _, value := range a {
		fmt.Println( value )
	}

	var q [5]int = [5]int { 10, 20, 30, 40, 50 }
	var r [5]int = [5]int { 10, 20, 30 }

	fmt.Printf("\nData Type: %T", q )
	fmt.Printf("\nData Type: %T", r )


	fmt.Println("\nArray Length: ", len( q ) )
	for index, value := range q {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	fmt.Println("\nArray Length: ", len( r ) )
	for index, value := range r {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	// 1. Type Inferencing Will Happen From RHS : [4]int
	// 2. Inferred Type Binded With LHS
	s := [...]int{ 10, 20, 100, 111 }
	fmt.Println("\nArray Length: ", len( s ) )
	for index, value := range s {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}
	fmt.Printf("\nData Type: %T", s )

	// Creating Slice
	ss := []int{ 10, 20, 100, 111 }
	fmt.Println("\nArray Length: ", len( ss ) )
	for index, value := range ss {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}
	fmt.Printf("\nData Type: %T", ss )

	some := [3]int { 100, 200, 300 }
	fmt.Println("\nArray Length: ", len( some ) )	
	fmt.Printf("\nData Type: %T", some )

	someAgain := [...]int { 99 : - 1 }
	fmt.Println("\nArray Length: ", len( someAgain ) )
	fmt.Printf("\nData Type: %T", someAgain )

	for index, value := range someAgain {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

// Array Length:  3
// Data Type: [3]int

// Array Length:  100
// Data Type: [100]int

	something := [10]int { 10, 20, 5 : 99, 7 : 88 }
	fmt.Println("\nArray Length: ", len( something ) )
	fmt.Printf("\nData Type: %T", something )

	for index, value := range something {
		fmt.Printf("\nAt Index: %d Value: %d", index, value) 
	}

	aa := [2]int { 10, 20 }
	bb := [...]int {10, 20 }
	cc := [2]int{ 10, 30 }

	// In Go Lang
	//		Can Compare Arrays Using == Operator
	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	dd := [3]int { 10, 30 }
	fmt.Println( dd )

	// Compilation Error
	// invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )
}

//__________________________________________________

func playWithSlices() {
	// Array Of Strings
	months := [...]string { 0: "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", 
					"Aug", "Sep", "Oct", "Nov", "Dec" }
	fmt.Println( months )

	// Slices
	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer 	:= months[ 2 : 7 ]

	fmt.Println( "Quater1 :", quater1 )
	fmt.Println( "Quater2 :", quater2 )
	fmt.Println( "Summear :", summer )

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf(" %s Month Appears In Both\n", s)
			}
		}
	}

	fmt.Printf("\n Data Type: %T", months )
	fmt.Printf("\n Data Type: %T", quater1 )
	fmt.Printf("\n Data Type: %T", quater2 )
	fmt.Printf("\n Data Type: %T", summer)

// Array Type
	 // Data Type: [13]string

// Slices Type
	 // Data Type: []string
	 // Data Type: []string
	 // Data Type: []string

	fmt.Println()
	fmt.Println( quater1[0] )
	fmt.Println( quater1[1] )
	fmt.Println( quater1[2] )

	fmt.Println( months[0] )
	fmt.Println( months[1] )
	fmt.Println( months[2] )

	fmt.Println()
	fmt.Println( quater2[0] )
	fmt.Println( quater2[1] )
	fmt.Println( quater2[2] )
}

//_____________________________________________________________________________________
// 						
// 									GO SLICES CONCEPTS
//_____________________________________________________________________________________

// Slices represent variable-length sequences whose elements all have 
//	the same type. A slice type is written []T, where the elements 
//  have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence 
// (or perhaps all) of the elements of an array, which is known as the 
// slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is reachable 
//			through the slice, which is not necessarily the array’s first element. 
// 		The length is the number of slice elements; it can’t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 	which may be an array variable, a pointer to an array, or another slice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j is omitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of valid months, 
// 	as does the slice months[1:]; the slice months[:] refers to the whole array.


//__________________________________________________

// In Go Lang
//		By Default Arrays Are Pass By Value

// In Java/C/C++
//		By Default Arrays Are Pass By Reference

func changeArray( someArray [5]int ) {
	fmt.Println("Inside changeArray Function: ", someArray )
	for index, _ := range someArray {
		someArray[index] = 777
	}

	fmt.Println("Inside changeArray Function: ", someArray )
}

// Here Array Is Passed By Reference
func changeArray1( someArray * [5]int ) {
	fmt.Println("Inside changeArray Function: ", someArray )
	for index, _ := range someArray {
		someArray[index] = 777
	}

	fmt.Println("Inside changeArray Function: ", someArray )
}

// In Go Lang
//		Slices Are Pass By Reference
func changeArray2( someSlice []int ) {
	fmt.Println("Inside changeArray Function: ", someSlice )
	for index, _ := range someSlice {
		someSlice[index] = 777
	}

	fmt.Println("Inside changeArray Function: ", someSlice )
}

func playWithChangeArray() {
	var aa [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println( "Array Before changeArray Called:", aa )
	changeArray( aa )
	fmt.Println( "Array After  changeArray Called:", aa )

	fmt.Println( "Array Before changeArray1 Called:", aa )
	changeArray1( &aa ) // Passing Array Reference
	fmt.Println( "Array After  changeArray1 Called:", aa )

	var bb [5]int = [5]int { 10, 20, 30, 40, 50 }
	fmt.Println( "Array Before changeArray2 Called:", bb )
	// Passing Array Slice of Full Array 
	//		Slice Index From 0 To len -1 i.e. bb[ 0 : len - 1 ]
	changeArray2( bb[ : ] ) 
	fmt.Println( "Array After  changeArray2 Called:", bb )
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main() {
	fmt.Println("\nFunction: playWithArrays");
	playWithArrays()

	fmt.Println("\nFunction: playWithSlices");
	playWithSlices()

	fmt.Println("\nFunction: playWithChangeArray");
	playWithChangeArray()

	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
	// fmt.Println("\nFunction: ");
}

