
#include <stdio.h>

//__________________________________________________

void playWithPointers() {
	int some = 100;
	// Assigning Address Of some Using & Operator
	int * pointer = &some;

	int value = *pointer;

	printf("\n Value: %d", some );
	printf("\n Address: %p", pointer );
	printf("\n Value At Pointer : %d", value );

	int **pointerToPointer = &pointer;
	printf("\n Value At Pointer : %d", **pointerToPointer );
}

//__________________________________________________

int sum(int a, int b) { return a + b; }

void changeArray( int someArray[] ) {
	for ( int  i = 0 ; i < 5 ; i++ ) {
		someArray[i] = 777;
	}
}

void playWithArraysAndPointers() {
	// UserName and Password
	int aa[5] = {10, 20, 30, 40, 50};

	int k = sum(a, b);

	for ( int  i = k ; i < 10 ; i++ ) {
		printf("\n %d", aa[i] );
	}

	int *ptr = aa;
	for ( int  i = k ; i < 10 ; i++ ) {
		printf("\n %d", * ( ptr + i ) );
	}

	// aa Is Address OF Contigous Memory Location
	// 		aa Is Pass By Value
	//		aa Reference OF Continous Memory Location [ARRAY]
	//		Array Is Pass By Reference
	changeArray( aa );
	for ( int  i = 0 ; i < 5 ; i++ ) {
		printf("\n %d", aa[i] );
	}	
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\nFunction : playWithPointers");
	playWithPointers();

	printf("\nFunction : playWithArraysAndPointers");
	playWithArraysAndPointers();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	return 0;
}

